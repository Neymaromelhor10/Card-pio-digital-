# ARGON 4 — MISSÃO 13: RELATÓRIO DE AUDITORIA CONSOLIDADA DAS PENDÊNCIAS E PLANO DE CORREÇÕES TÉCNICAS

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 13 — Auditoria Consolidada das Pendências e Plano de Correções Técnicas  
**Base Preservada:** Backup intacto da Missão 12 em `argon4-pizzaria-fullstack-backup-missao12.zip` (SHA-256: `ecb6bbcd17cb504017ab956b7828b3446b875ff8a81bcc1b3f5d8e4e80cb5953`)  
**Data:** 2026-11-17  
**Escopo Respeitado:** Nenhuma configuração externa (GitHub, Codespaces, Supabase ou deploy) foi iniciada; nenhum redesign visual; nenhum escopo multi-tenant/SaaS adicionado.

---

## 1. Resumo Executivo

A Missão 13 realizou uma auditoria forense consolidada nas 7 dimensões do sistema (A. Arquitetura e Persistência; B. Catálogo e Administração; C. Carrinho e Checkout; D. Operação dos Pedidos; E. Segurança; F. Interface e Experiência; G. PostgreSQL e Supabase) cobrindo todo o histórico das Missões 01 a 12.

Foram identificados **3 erros confirmados no código** (que causariam falha silenciosa de listagem administrativa de pedidos, perda de `external_id` de produtos em `order_items` e reset do contador `used_count` de cupons ao operar com PostgreSQL) e **1 melhoria de acessibilidade de interface** (fechamento de modais por tecla `Escape` e `aria-label`). Todos os 4 pontos foram corrigidos localmente e cobertos pelo novo **Subteste 24**, elevando a suíte para **24/24 testes aprovados (`0` falhas)**.

---

## 2. Tabela Consolidada e Classificação das Pendências (Seção 4)

### 2.1 Categoria 1 — Erros Confirmados no Código (Corrigidos e Testados nesta Missão 13)

| ID | Arquivo / Componente | Problema Identificado | Gravidade | Evidência Encontrada | Correção Implementada | Dep. Externa | Teste que Comprova |
|---|---|---|---|---|---|---|---|
| **M13-E01** | `server/src/domain/argon4Engine.mjs` (`_applyLoadedDatabaseState`) | Sobrescrita indevida de `c.used_count` dos cupons quando `data.coupons_usage` vinha vazio (`{}`) do `PostgresOrderStore.loadAll()`. | **Alta** | Linha 767: `if (data.coupons_usage)` era verdadeiro para `{}` e recalculava `c.used_count = baseUsed + 0`, descartando o `used_count` real gravado na tabela `public.coupons` do PostgreSQL. | Alterada condição para `if (data.coupons_usage && Object.keys(data.coupons_usage).length > 0)`, preservando `c.used_count` da tabela `public.coupons` quando o driver é PostgreSQL. | Nenhuma | `Subteste 24` (item 1) + `Subteste 1/2` (SQLite) |
| **M13-E02** | `server/src/db/postgresOrderStore.mjs` (`loadAll`, `getOrderByIdempotencyKey`, `getOrderByIdOrCode`, `createOrderTransaction`) | Pedidos carregados do PostgreSQL retornavam `establishment_id` como UUID v5 (`be2cb127-...`) em vez de `'est-forno-nobre-01'` porque as queries `SELECT o.* FROM public.orders o` não projetavam `app_est_id`. No Painel Admin (`/api/admin/dashboard`), o filtro `o.establishment_id === 'est-forno-nobre-01'` descartaria os pedidos. | **Alta** | `_hydrateOrderRow` lia `row.app_est_id || row.establishment_id`, mas nenhuma query em `public.orders` selecionava `app_est_id`. | Adicionado `COALESCE((SELECT e.external_id FROM public.establishments e WHERE e.id = o.establishment_id), o.establishment_id::text) AS app_est_id` em todas as queries de `public.orders` e no retorno de `createOrderTransaction`. | Nenhuma | `Subteste 24` (item 2) |
| **M13-E03** | `server/src/db/postgresOrderStore.mjs` (`loadAll`, `getOrderByIdempotencyKey`, `getOrderByIdOrCode`, `createOrderTransaction`) | Itens de pedidos (`public.order_items`) carregados do PostgreSQL retornavam `product_id` como UUID v5 em vez do `external_id` (`prod-pepperoni-burrata`). | **Média** | `_hydrateOrderRow` lia `ir.app_product_id || ir.product_id`, mas as queries em `public.order_items` faziam apenas `SELECT *` sem resolver `external_id` de `public.products`. | Adicionado `COALESCE((SELECT p.external_id FROM public.products p WHERE p.id = oi.product_id), oi.product_id::text) AS app_product_id` em todas as leituras de `public.order_items`. | Nenhuma | `Subteste 24` (item 2) |
| **M13-E04** | `public/index.html` (Modais e Acessibilidade) | Modais (`customizerModal`, `cartCheckoutModal`, `orderConfirmationModal`) não possuíam `aria-label`/`aria-labelledby` nem fechamento via tecla `Escape`, e o botão `✕` do checkout não tinha `aria-label`. | **Baixa** | Inspeção das linhas 259–290 de `public/index.html`. | Adicionados `aria-label`/`aria-labelledby` nos 3 modais, `aria-label="Fechar carrinho e checkout"` no botão `✕` e listener global `keydown` (`Escape`). | Nenhuma | `Subteste 24` (item 3) + Chromium E2E |

---

### 2.2 Categoria 2 — Riscos Técnicos Identificados (Que Exigem Decisão Arquitetural Futura)

| ID | Componente | Risco Identificado | Gravidade | Decisão Recomendada (Não Executada Automaticamente) |
|---|---|---|---|---|
| **M13-R01** | `server/src/index.mjs` (`revokedSessionJtis` e `rateLimitBuckets`) | Estado de revogação de sessões (`jti`) e contadores de rate limiting residem em memória do processo Node.js. Se o servidor for escalado horizontalmente para múltiplas instâncias, o rate limit não será compartilhado. | **Baixa** (para 1 pizzaria) | Manter 1 instância Node.js persistente para operação monolocal de uma única pizzaria (suficiente para centenas de pedidos simultâneos) ou migrar revogação/rate-limit para tabela PostgreSQL caso escale horizontalmente no futuro. |
| **M13-R02** | `public/index.html` (Tailwind CDN `cdn.tailwindcss.com`) | Uso do runtime JIT da CDN do Tailwind no navegador em vez de CSS pré-compilado em build step. | **Baixa** | A página já possui fallback CSS nativo (`390x844` sem overflow mesmo offline). Em missão futura de otimização de performance, pode-se compilar um arquivo `styles.css` estático se desejado. |

---

### 2.3 Categoria 3 — Testes que Ainda Faltam Executar (Exigem Serviços Externos)

| ID | Teste Pendente | Motivo pelo qual não foi executado nesta missão | Comando Pronto |
|---|---|---|---|
| **M13-T01** | Execução real das 9 migrations (`0001`–`0009`) + 15 etapas de concorrência/rollback/seed contra PostgreSQL real | Ausência de daemon PostgreSQL/Supabase e pacote `pg` no container offline. | `npm run homolog:pg` |
| **M13-T02** | Validação dinâmica das políticas RLS (`anon`, `authenticated`, `service_role` e auditoria `rolbypassrls`) | Exige instância PostgreSQL/Supabase real com roles `anon`/`authenticated`/`service_role`. | `npm run test:pg:rls` |

---

### 2.4 Categoria 4 — Pendências que Dependem de PostgreSQL / Supabase Real

1. Provisionar banco PostgreSQL 15+ / Supabase de **homologação** e configurar `DATABASE_URL`.
2. Executar `npm run homolog:pg` e `npm run test:pg:rls` para comprovar em banco real a aplicação das migrations `0001`–`0009`, o seed transacional e as políticas RLS.

---

### 2.5 Categoria 5 — Pendências que Dependem de GitHub / Codespaces / Hospedagem

1. Executar `npm install` com acesso ao registry npm (no GitHub Codespaces) para baixar o pacote `pg` e gerar o `package-lock.json` oficial, validando em seguida com `npm ci`.
2. Configurar Secrets (`DATABASE_URL`, `ADMIN_API_TOKEN`, `SESSION_SECRET`, `CORS_ALLOWED_ORIGINS`) no Codespaces e, posteriormente, no provedor de hospedagem Node.js persistente (Render/Railway/Docker).

---

## 3. Registro Detalhado das Correções Executadas (Seção 5)

1. **`[M13-E01]` Preservação de `used_count` de cupons no PostgreSQL (`server/src/domain/argon4Engine.mjs`):**
   - *Comportamento anterior:* `_applyLoadedDatabaseState` executava `if (data.coupons_usage)` e sobrescrevia `c.used_count = baseUsed + (data.coupons_usage[c.id] || 0)`. Como `PostgresOrderStore` retorna `coupons_usage: {}`, o contador voltava ao valor base a cada sincronização.
   - *Causa:* `coupons_usage` é uma tabela auxiliar exclusiva do legado SQLite; no PostgreSQL, `used_count` é incrementado diretamente em `public.coupons`.
   - *Correção:* Condição restrita a `if (data.coupons_usage && Object.keys(data.coupons_usage).length > 0)`.
   - *Teste:* Subteste 24 (item 1) + Subteste 1/2 (SQLite).
2. **`[M13-E02]` e `[M13-E03]` Resolução de `app_est_id` e `app_product_id` em Pedidos (`server/src/db/postgresOrderStore.mjs`):**
   - *Comportamento anterior:* `SELECT o.* FROM public.orders o` e `SELECT * FROM public.order_items` retornavam apenas os UUIDs internos (`establishment_id` e `product_id`), sem projetar `app_est_id` e `app_product_id` esperados por `_hydrateOrderRow`.
   - *Causa:* Nas Missões 09/10, a projeção de `external_id` havia sido adicionada nas queries de catálogo, mas omitida nas queries de `orders` e `order_items`.
   - *Correção:* Adicionadas subconsultas `COALESCE((SELECT e.external_id ...), o.establishment_id::text) AS app_est_id` e `COALESCE((SELECT p.external_id ...), oi.product_id::text) AS app_product_id` em `loadAll()`, `getOrderByIdempotencyKey()`, `getOrderByIdOrCode()` e `createOrderTransaction()`.
   - *Teste:* Subteste 24 (item 2).
3. **`[M13-E04]` Acessibilidade de Modais e Tecla `Escape` (`public/index.html`):**
   - *Comportamento anterior:* Modais sem `aria-label`/`aria-labelledby` e sem fechamento por `Escape`.
   - *Correção:* Adicionados atributos ARIA e listener global `keydown` (`Escape`).
   - *Teste:* Subteste 24 (item 3) e teste real no Chromium Headless (`390x844`).

---

## 4. Resultado Individual dos Testes de Regressão (Seção 6)

| Suíte / Verificação | Natureza do Teste | Resultado | Tempo |
|---|---|---|---|
| `node scripts/verify-migrations-order.mjs` (`0001`–`0009`) | **Inspeção Estática SQL** | **PASSOU (`9/9`)** | `< 50 ms` |
| Subtestes 1 a 16 (`tests/argon4-suite.mjs`) | **REAL (SQLite 3.40.1 WAL + HTTP + Concorrência 100 Clientes + RBAC/HMAC)** | **PASSOU (`16/16`)** | `17.50 s` |
| Subteste 17 (`tests/argon4-suite.mjs`) | **MOCK (`pg.Pool`) + Fail-Closed** | **PASSOU (`1/1`)** | `7.06 ms` |
| Subtestes 18, 19 e 20 (`tests/argon4-suite.mjs`) | **REAL (SQLite + HTTP: CRUD Catálogo, 25 Cenários E2E, SQLi/XSS/PII)** | **PASSOU (`3/3`)** | `1.88 s` |
| Subtestes 21, 22, 23 e 24 (`tests/argon4-suite.mjs`) | **REAL (UUID v5 RFC 4122, `/api/health`, `envLoader`) + MOCK (`pg.Pool` Stateful)** | **PASSOU (`4/4`)** | `128.5 ms` |
| **Total `npm test`** | **24 Suítes Automatizadas** | **24/24 PASS (`0` falhas)** | **`20.46 s`** |
| `node scripts/run-browser-e2e-chromium.mjs` | **REAL (Chromium Headless `390x844` + SQLite + HTTP)** | **PASSOU (`ok: true`, `#PZ-9041`, `confirmed`, `scrollWidth: 390`, `js_errors: 0`)** | `~2.5 s` |
| `node scripts/check-codespaces-env.mjs` | **REAL (Diagnóstico de Ambiente)** | **PASSOU (`ok: true`)** | `< 80 ms` |
| `node --test tests/postgres-integration-rls.mjs` | **REAL (PostgreSQL Dinâmico — Depende de Ambiente Externo)** | **SKIP (Offline)** | `122 ms` |

---

## 5. Próxima Missão Recomendada

- **Missão 14 Recomendada:** **Execução da Homologação Real no GitHub Codespaces + Supabase Staging**, realizando a abertura do repositório no Codespaces, geração do `package-lock.json` via `npm install`, conexão da `DATABASE_URL` do projeto Supabase de homologação e execução real de `npm run homolog:pg` e `npm run test:pg:rls`.
