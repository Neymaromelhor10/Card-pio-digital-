# RELATÓRIO TÉCNICO DE AUDITORIA FORENSE E BLINDAGEM DE SEGURANÇA — ARGON 4: MISSÃO 04

## 1. Resumo Executivo
Esta missão realizou uma auditoria forense independente e adversarial sobre o pacote validado na Missão 03 (`argon4-pizzaria-fullstack.zip`), identificou **7 vulnerabilidades de segurança** (**3 CRÍTICAS**, **3 ALTAS** e **1 MÉDIA**) e implementou correções cirúrgicas no backend (`server/src/index.mjs`, `server/src/domain/argon4Engine.mjs`, `server/src/db/sqliteOrderStore.mjs`, `server/src/start.mjs`), no frontend (`public/index.html`), em `.env.example` e no banco PostgreSQL/Supabase via migration incremental `0006_argon4_security_rls_multitenant_hardening.sql`, validando **20+ cenários adversariais** e todas as **16 suítes de testes automatizados (`16/16 PASS`, `0` falhas)**.

### Síntese Objetiva (Corrigido vs. Testado vs. Não Testado vs. Bloqueios de Produção)
- **O que foi efetivamente corrigido**:
  1. Eliminação total de segredos padrão hardcoded (`'argon4-admin-secret-token'`, `'meta-app-secret-key'`, `'argon4-verify-token'`, `'argon4-demo-hash'` e PIN `'102030'`) e ativação de bloqueio **Fail-Closed (`503 AUTH_CONFIG_MISSING_OR_INSECURE`)** quando variáveis críticas de autenticação não estão configuradas ou usam placeholders.
  2. Implementação de tokens de sessão administrativa assinados com **HMAC-SHA256 (`argon4_sess.<payload>.<sig>`)**, comparação em tempo constante (`crypto.timingSafeEqual`), expiração obrigatória (`exp`), revogação de sessão (`jti` via `POST /api/admin/session/logout`) e separação estrita de papéis (**RBAC**: `platform_owner`, `establishment_admin`, `kitchen_operator` e `public`).
  3. Blindagem contra **IDOR/BOLA** em pedidos: `order_access_token` comparado via `crypto.timingSafeEqual`, acrescido de expiração explícita (`access_token_expires_at`, padrão 24h) e vínculo obrigatório ao `establishment_id`.
  4. Isolamento **Multi-Estabelecimento** no motor de domínio e banco (`UNIQUE(establishment_id, idempotency_key)`, `UNIQUE(establishment_id, public_code)`), validado com **3 pizzarias independentes** (`est-forno-nobre-01`, `est-bella-napoli-002`, `est-don-luigi-003`), bloqueando compras cruzadas de produtos/cupons e acessos administrativos entre estabelecimentos (`403 CROSS_ESTABLISHMENT_ADMIN_FORBIDDEN`).
  5. Hardening de **PostgreSQL / Supabase / RLS** na migration `0006_argon4_security_rls_multitenant_hardening.sql`: `SET search_path = public, pg_temp` em todas as funções `SECURITY DEFINER`, `REVOKE ALL` de tabelas sensíveis para `anon`/`PUBLIC`, políticas RLS por `establishment_id` e papel administrativo, e criação da view pública higienizada `public.v_public_storefront_settings`.
  6. Rate limiting proporcional por rota, proteção contra **Brute Force** administrativo (`429 TOO_MANY_AUTH_ATTEMPTS` + `Retry-After`) e **Anti-IP-Spoofing** (`trustProxy = false` por padrão, ignorando `X-Forwarded-For` falsificado).
  7. Blindagem de **Webhooks** com validação de estrutura JSON, janela anti-replay de timestamp (`±300s` -> `400 WEBHOOK_TIMESTAMP_EXPIRED_OR_REPLAY`) e deduplicação persistente na tabela `webhook_events_dedup`.
- **O que foi testado com evidência real**:
  - Os **20 cenários adversariais obrigatórios** da Seção 11 + isolamento entre **3 estabelecimentos** + regressão completa das Missões 02, 03, 04 e 05 (`16/16` suítes aprovadas em `tests/argon4-suite.mjs` contra o servidor Node.js HTTP e banco SQLite 3.40.1 ACID).
- **O que não pôde ser testado neste ambiente**:
  - A execução dinâmica das políticas RLS diretamente contra uma instância ativa do motor PostgreSQL/PostgREST (`supabase start` / `psql`), pois o container de homologação offline não possui o binário/serviço PostgreSQL instalado nem acesso de rede externo ao Supabase Cloud. As políticas RLS e grants foram validadas por auditoria estática e estrutural na migration `0006`.
- **O que ainda impede a entrada imediata em produção**:
  1. Aplicação e bateria de testes dinâmicos da migration `0006_argon4_security_rls_multitenant_hardening.sql` em uma instância real Supabase/PostgreSQL de staging com tokens JWT reais de `anon`, `authenticated` e `service_role`.
  2. Execução do teste prolongado de carga de 32 minutos (`scripts/k6-homologation-load-test.js`) no ambiente de staging externo.
  3. Implementação do adaptador de persistência PostgreSQL nativo (`pg` / Supabase RPC client) para substituir o driver local SQLite quando `DATABASE_URL` estiver ativo em produção, além do transporte definitivo da WhatsApp Cloud API (previsto para missão dedicada).

---

## 2. Inventário Completo de Endpoints HTTP e Classificação (Seção 4)

| Endpoint | Método | Classificação | Finalidade | Dados Recebidos | Dados Retornados | Autenticação Exigida | Autorização Exigida | Validação de Entrada & Abuso Mitigado | Status Teste |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `/` e `/index.html` | `GET` | Pública | Servir a interface do cardápio digital | Path estático | HTML/MP4/JPG com `X-Content-Type-Options: nosniff` | Nenhuma | Pública | Path traversal bloqueado (`safePath.startsWith(PUBLIC_DIR)`) | **PASS** |
| `/api/catalog` | `GET` | Pública | Retornar catálogo público do estabelecimento ativo | Header/Query opcional `X-Establishment-Id` | Categorias, produtos, sabores, tamanhos e settings públicos (sem `pix_key` nem segredos) | Nenhuma (bloqueia se enviar `service_role`) | Pública (somente leitura de itens ativos) | Valida existência do estabelecimento; bloqueia `apikey` contendo `service_role` (`403`) | **PASS** |
| `/api/cart/calculate` | `POST` | Operacional / Pública | Calcular prévia de subtotal, frete por bairro e cupom no servidor | `{ items, fulfillmentType, neighborhood, couponCode }` | Totais verificados em centavos | Nenhuma | Pública (escopo do estabelecimento) | Valida quantidades `1..50`, produtos, sabores, adicionais e pertencimento ao estabelecimento | **PASS** |
| `/api/orders` | `POST` | Rastreamento e Pedidos | Criar pedido transacional persistente com idempotência | `{ idempotency_key, customer, address, items, payment_method, ... }` + `Idempotency-Key` | `{ persisted: true, order, order_access_token }` (`201` ou `200`) | Chave de idempotência obrigatória | Cliente público no escopo do estabelecimento | Recalcula 100% dos preços no servidor; bloqueia cross-tenant (`400`), payload/cliente conflitante (`409`) e flood por `(IP, sessão/telefone)` (`429`) | **PASS** |
| `/api/orders/:id` | `GET` | Rastreamento e Pedidos | Consultar status e resumo de um pedido específico | `:id` ou `:public_code` + header `X-Order-Access-Token` (ou `Bearer` Admin) | `{ order }` higienizado | `X-Order-Access-Token` ou `Bearer` Admin | Dono do pedido (token válido, não expirado e mesmo estabelecimento) ou Admin do estabelecimento | Comparação `timingSafeEqual` do hash do token, verificação de `access_token_expires_at` e bloqueio de IDOR/BOLA (`403`) | **PASS** |
| `/api/orders/*` | `PUT`, `PATCH`, `DELETE` | Bloqueada (Proteção Integridade) | Impedir alteração, cancelamento ou exclusão de pedidos por clientes | Qualquer corpo/parâmetro | `403 FORBIDDEN_ORDER_MODIFICATION` | Bloqueado para clientes | Nenhuma (operação proibida na rota pública) | Registra tentativa em `operation_audit_logs` e retorna `403` | **PASS** |
| `/api/tracking/events` | `POST` | Rastreamento e Pedidos | Registrar eventos de funil GA4/GTM/Meta CAPI com deduplicação | `{ event_id, event_name, value_cents, consent_granted, payload }` | `{ deduplicated, event }` | Nenhuma | Pública | Deduplicação por `event_id UNIQUE`; respeita `consent_granted` (LGPD) | **PASS** |
| `/api/webhooks/whatsapp` | `GET` | Webhooks | Handshake de verificação do webhook Meta Cloud API | `hub.mode`, `hub.verify_token`, `hub.challenge` | Texto puro `hub.challenge` (`200`) ou `403`/`503` | `hub.verify_token` | Meta Webhook Verifier | Comparação `timingSafeEqual`; falha fechado (`503`) se `WHATSAPP_VERIFY_TOKEN` não configurado | **PASS** |
| `/api/webhooks/whatsapp` | `POST` | Webhooks | Receber callbacks de status de mensagens (`sent`, `delivered`, `read`) | Corpo JSON assinado + header `x-hub-signature-256` | `{ processed, deduplicated_count, deduplicated }` | Assinatura HMAC-SHA256 sobre raw body | Meta WhatsApp Cloud API | Valida HMAC (`401`), estrutura JSON (`400`), janela de timestamp `±300s` anti-replay (`400`) e deduplicação em `webhook_events_dedup` | **PASS** |
| `/api/admin/dashboard` | `GET` | Administrativa | Listar pedidos, mensagens WhatsApp e métricas do estabelecimento | Header `Authorization: Bearer <token>` + `establishment_id` opcional | Pedidos e configurações filtrados pelo estabelecimento autorizado | `Bearer` Admin (Sessão HMAC ou Token Root) | `platform_owner`, `establishment_admin` ou `kitchen_operator` (restrito ao seu `establishment_id`) | Bloqueia token ausente/inválido/expirado/revogado (`401`), brute force (`429`) e leitura de outro estabelecimento (`403`) | **PASS** |
| `/api/admin/orders/status` | `PATCH` | Administrativa / Operacional | Atualizar estado operacional do pedido (`confirmed`, `preparing`, etc.) | `{ orderId, newStatus, notes }` + `Bearer` Admin | `{ order, whatsapp_notification }` | `Bearer` Admin | `platform_owner`, `establishment_admin` ou `kitchen_operator` do próprio estabelecimento | Valida transição de status e bloqueia alteração de pedido de outra pizzaria (`403 CROSS_ESTABLISHMENT_ADMIN_FORBIDDEN`) | **PASS** |
| `/api/admin/orders/confirm-payment` | `POST` | Administrativa Financeira | Confirmar manualmente recebimento de pagamento Pix/Dinheiro/Cartão | `{ orderId }` + `Bearer` Admin | `{ order }` | `Bearer` Admin | **Apenas** `platform_owner` ou `establishment_admin` do próprio estabelecimento | Bloqueia `kitchen_operator` (`403 INSUFFICIENT_ADMIN_ROLE`) e bloqueia cross-tenant (`403`) | **PASS** |
| `/api/admin/observability` | `GET` | Observabilidade / Interna | Consultar métricas de latência, integridade SQLite e `operation_audit_logs` | Header `Authorization: Bearer <token>` | `{ metrics, db_integrity, audit_logs }` (Zero PII) | `Bearer` Admin | **Exclusivo** `platform_owner` | Bloqueia `establishment_admin`, `kitchen_operator` (`403`) e anônimos (`401`) | **PASS** |
| `/api/admin/session/logout` | `POST` | Administrativa | Revogar imediatamente o `jti` da sessão administrativa atual | Header `Authorization: Bearer <session_token>` | `{ revoked: true }` | `Bearer` Admin | Qualquer papel administrativo autenticado | Adiciona `jti` à lista de sessões revogadas; uso posterior retorna `401 ADMIN_SESSION_REVOKED` | **PASS** |
| `/rest/v1/*`, `/api/db/*`, `/api/internal/*`, `/supabase/*` | `ALL` | Interna / Bloqueada | Impedir acesso direto a tabelas protegidas fora da camada de domínio | Qualquer requisição | `403 DIRECT_TABLE_ACCESS_FORBIDDEN` | Bloqueado | Proibido | Bloqueia imediatamente e registra tentativa em `operation_audit_logs` | **PASS** |

---

## 3. Matriz de Autenticação e Autorização (RBAC e Isolamento por Papel)

| Operação / Recurso | Cliente Público (`anon`) | Cliente com `X-Order-Access-Token` | Operador de Cozinha (`kitchen_operator`) | Admin da Pizzaria (`establishment_admin`) | Proprietário da Plataforma (`platform_owner`) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Consultar cardápio ativo (`GET /api/catalog`) | Permitido (somente dados públicos) | Permitido | Permitido | Permitido | Permitido |
| Criar pedido (`POST /api/orders`) | Permitido (preços recalculados no servidor) | Permitido | Permitido | Permitido | Permitido |
| Consultar pedido específico (`GET /api/orders/:id`) | **Bloqueado (`403`)** | **Permitido apenas para o próprio pedido** (dentro do TTL e mesmo estabelecimento) | Permitido apenas para pedidos do seu estabelecimento | Permitido apenas para pedidos do seu estabelecimento | Permitido (todos os estabelecimentos) |
| Modificar/excluir pedido via rota pública (`PUT/PATCH/DELETE /api/orders/*`) | **Bloqueado (`403`)** | **Bloqueado (`403`)** | **Bloqueado (`403`)** | **Bloqueado (`403`)** | **Bloqueado (`403`)** |
| Visualizar dashboard (`GET /api/admin/dashboard`) | **Bloqueado (`401`)** | **Bloqueado (`401`)** | Permitido (**apenas seu estabelecimento**) | Permitido (**apenas seu estabelecimento**) | Permitido (visão global multi-pizzaria) |
| Atualizar status operacional (`PATCH /api/admin/orders/status`) | **Bloqueado (`401`)** | **Bloqueado (`401`)** | Permitido (**apenas seu estabelecimento**) | Permitido (**apenas seu estabelecimento**) | Permitido (todos os estabelecimentos) |
| Confirmar pagamento financeiro (`POST /api/admin/orders/confirm-payment`) | **Bloqueado (`401`)** | **Bloqueado (`401`)** | **Bloqueado (`403 INSUFFICIENT_ADMIN_ROLE`)** | Permitido (**apenas seu estabelecimento**) | Permitido (todos os estabelecimentos) |
| Consultar telemetria e logs (`GET /api/admin/observability`) | **Bloqueado (`401`)** | **Bloqueado (`401`)** | **Bloqueado (`403 INSUFFICIENT_ADMIN_ROLE`)** | **Bloqueado (`403 INSUFFICIENT_ADMIN_ROLE`)** | **Permitido (Exclusivo)** |

---

## 4. Matriz de Permissões RLS e Grants no PostgreSQL / Supabase (Migrations `0001` a `0006`)

| Tabela / View / Função (`public.*`) | RLS Ativo | Papel `anon` (Navegador Público) | Papel `authenticated` (Admin Autenticado) | Papel `service_role` (Backend API) | Política de Isolamento Aplicada (`0001` + `0006`) |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `establishments` | Sim | `SELECT` | `SELECT` | `ALL` | Leitura pública de identidade da loja (`public_read_establishments`) |
| `categories`, `pizza_sizes`, `products`, `product_variations`, `pizza_flavors`, `product_addons`, `promotions` | Sim | `SELECT` (apenas registros ativos/não excluídos) | `SELECT` + `ALL` restrito a `owner`/`manager` do próprio `establishment_id` | `ALL` | Escrita exige `current_user_has_establishment_role(establishment_id, ARRAY['owner','manager'])` |
| `v_public_storefront_settings` *(View)* | View Segura | `SELECT` | `SELECT` | `SELECT` | Expõe apenas flags de pagamento, regra meio-a-meio e zonas de entrega sem segredos |
| `store_settings` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT`, `UPDATE` restrito a `owner`/`manager` do `establishment_id` | `ALL` | `rls_store_settings_select` / `rls_store_settings_modify` |
| `admin_users` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT` (`owner`/`manager` do tenant); `ALL` (`owner` do tenant) | `ALL` | `rls_admin_users_select` / `rls_admin_users_manage` |
| `coupons` | Sim | **NENHUM (`REVOKE ALL`)** | `ALL` restrito a `owner`/`manager` do `establishment_id` | `ALL` | Validação de cupom ocorre no backend; `anon` não lista cupons diretamente |
| `customers` & `customer_addresses` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT` restrito a `owner`/`manager`/`operator` do `establishment_id` | `ALL` | Protege PII de clientes contra leitura pública e contra outras pizzarias |
| `orders` & `order_items` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT`, `UPDATE` restrito a `owner`/`manager`/`kitchen`/`operator` do `establishment_id` | `ALL` | Isolamento estrito por `establishment_id` (`rls_orders_tenant_select/update`) |
| `payments` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT` (`owner`/`manager`/`operator`); `UPDATE` (`owner`/`manager` do tenant) | `ALL` | Operador de cozinha não altera status financeiro no banco |
| `order_status_history` & `whatsapp_outbox` & `whatsapp_messages` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT` restrito ao `establishment_id` do usuário | `ALL` | `rls_whatsapp_outbox_tenant_select` |
| `campaign_attributions` & `tracking_events` & `operation_audit_logs` & `webhook_events_dedup` | Sim | **NENHUM (`REVOKE ALL`)** | `SELECT` restrito a `owner`/`manager` do `establishment_id` | `ALL` | `rls_operation_audit_logs_tenant_select` |
| `create_order_transactional(...)` *(Função)* | `SECURITY DEFINER` | **NENHUM (`REVOKE EXECUTE`)** | **NENHUM (`REVOKE EXECUTE`)** | `EXECUTE` | `SET search_path = public, pg_temp`; executável exclusivamente pelo backend (`service_role`) |

---

## 5. Relação de Vulnerabilidades Encontradas e Correções Implementadas

| ID | Severidade | Vulnerabilidade Encontrada na Auditoria da Base Missão 03 | Correção Cirúrgica Implementada na Missão 04 | Status |
| :--- | :--- | :--- | :--- | :--- |
| **M04-V01** | **CRÍTICO** | **Credenciais padrão previsíveis em fallback (`server/src/index.mjs`)**: `adminToken` usava `'argon4-admin-secret-token'` e `whatsappAppSecret` usava `'meta-app-secret-key'` quando variáveis de ambiente estavam ausentes. | Removidos todos os fallbacks previsíveis; criado `FORBIDDEN_INSECURE_SECRETS` e `isSecretConfiguredAndSafe()`; rotas administrativas e webhooks agora operam em modo **Fail-Closed (`503`)** se segredos seguros não estiverem configurados; `server/src/start.mjs` aborta inicialização em `NODE_ENV=production` sem segredos fortes. | **CORRIGIDO E TESTADO** |
| **M04-V02** | **CRÍTICO** | **Ausência de RBAC, expiração e revogação de sessão administrativa**: todas as rotas `/api/admin/*` aceitavam um único token estático sem distinção entre `platform_owner`, `establishment_admin` e `kitchen_operator`, e sem expiração (`exp`) ou logout (`jti`). | Implementados `issueAdminSessionToken` e `verifyAdminSessionToken` com assinatura HMAC-SHA256 verificada via `crypto.timingSafeEqual`, expiração (`ADMIN_TOKEN_EXPIRED`), revogação via `POST /api/admin/session/logout` (`ADMIN_SESSION_REVOKED`) e controle RBAC por rota (`403 INSUFFICIENT_ADMIN_ROLE`). | **CORRIGIDO E TESTADO** |
| **M04-V03** | **CRÍTICO** | **Isolamento multi-estabelecimento incompleto**: `orders` tinha constraint global em `idempotency_key`/`public_code` no SQLite e administradores/clientes não eram validados contra múltiplos estabelecimentos independentes. | Adicionado suporte a múltiplos estabelecimentos (`registerEstablishment`, `getTenant`), constraint composta `UNIQUE(establishment_id, idempotency_key)` e `UNIQUE(establishment_id, public_code)`, bloqueio de produtos/sabores/adicionais/cupons cruzados (`400 CROSS_TENANT_ESTABLISHMENT_MISMATCH`) e bloqueio de leitura/mutação administrativa entre pizzarias (`403 CROSS_ESTABLISHMENT_ADMIN_FORBIDDEN`). | **CORRIGIDO E TESTADO** |
| **M04-V04** | **ALTO** | **Funções `SECURITY DEFINER` sem `search_path` fixo e tabelas com RLS sem políticas restritivas por tenant/role ou `REVOKE` para `anon`**: nas migrations `0001`–`0005`, `create_order_transactional` não definia `SET search_path` e faltavam políticas explícitas por `establishment_id`. | Criada a migration incremental `0006_argon4_security_rls_multitenant_hardening.sql` fixando `SET search_path = public, pg_temp`, revogando acesso de `anon`/`PUBLIC` às tabelas internas e definindo políticas RLS completas por `establishment_id` e `role`. | **CORRIGIDO (Migration `0006`)** |
| **M04-V05** | **ALTO** | **Rate limiting sem proteção específica contra brute-force administrativo e sem cabeçalhos `X-RateLimit-*`**: contador único global sem bloqueio de falhas sucessivas de login/token. | Implementado bloqueio de brute-force administrativo (`maxAuthFailuresPerMinute`, retornando `429 TOO_MANY_AUTH_ATTEMPTS` + `Retry-After`), rate limit de criação de pedidos por `(IP, sessão/telefone)` compatível com NAT, cabeçalhos `X-RateLimit-Limit/Remaining/Reset` e `trustProxy = false` por padrão (anti-IP-spoofing). | **CORRIGIDO E TESTADO** |
| **M04-V06** | **ALTO** | **Webhook WhatsApp sem validação de timestamp anti-replay e sem deduplicação de eventos repetidos**: reenvio do mesmo payload assinado era reprocessado indefinidamente. | Implementada janela de tolerância de timestamp (`±300s` -> `400 WEBHOOK_TIMESTAMP_EXPIRED_OR_REPLAY`), validação estrita da estrutura JSON (`400 INVALID_WEBHOOK_PAYLOAD`) e deduplicação persistente na tabela `webhook_events_dedup`. | **CORRIGIDO E TESTADO** |
| **M04-V07** | **MÉDIO** | **`order_access_token` sem expiração (`access_token_expires_at`) e comparação não-constante (`!==`), além de hash/PIN demonstrativo no HTML**: o token de consulta do pedido não expirava e o seed local do frontend continha `'argon4-demo-hash'` e PIN `'102030'`. | Adicionado `access_token_expires_at` (padrão 24h, retornando `403 ORDER_ACCESS_TOKEN_EXPIRED` quando vencido), comparação via `crypto.timingSafeEqual` e remoção completa de `'argon4-demo-hash'` e `'102030'` do frontend. | **CORRIGIDO E TESTADO** |

---

## 6. Resultados Individuais dos 20+ Testes Adversariais Obrigatórios (Seção 11) e Regressão (Seção 12)

| # | Cenário Adversarial / Teste Executado | Resultado Esperado | Resultado Observado | Status |
| :--- | :--- | :--- | :--- | :--- |
| **01** | Acesso administrativo sem token (`GET /api/admin/dashboard`) | `401 UNAUTHORIZED_ADMIN_ACCESS` | `401 UNAUTHORIZED_ADMIN_ACCESS` | **PASS** |
| **02** | Token administrativo inválido / forjado e token padrão antigo (`argon4-admin-secret-token`) | `401 INVALID_ADMIN_TOKEN` / `503` se servidor sem config | `401` (com config forte) e `503` (sem config / fail-closed) | **PASS** |
| **03** | Token administrativo expirado (`ttlSeconds: -10`) e sessão revogada (`POST /api/admin/session/logout`) | `401 ADMIN_TOKEN_EXPIRED` e `401 ADMIN_SESSION_REVOKED` | `401 ADMIN_TOKEN_EXPIRED` e `401 ADMIN_SESSION_REVOKED` | **PASS** |
| **04** | Tentativa de escalada de privilégios (`kitchen_operator` tentando confirmar pagamento ou adulterar `role` no token) | `403 INSUFFICIENT_ADMIN_ROLE` e `401 INVALID_ADMIN_TOKEN` | `403 INSUFFICIENT_ADMIN_ROLE` e `401 INVALID_ADMIN_TOKEN` | **PASS** |
| **05** | Acesso direto à API administrativa sem autenticação ou com segredo padrão inseguro | `401` / `503 AUTH_CONFIG_MISSING_OR_INSECURE` | Bloqueado no servidor com `401` / `503` | **PASS** |
| **06** | Consulta de pedido de outro cliente (IDOR/BOLA em 100 clientes independentes) | `403 FORBIDDEN_ORDER_ACCESS` sem vazar dados | `100/100` bloqueados com `403` e zero dados no corpo | **PASS** |
| **07** | Alteração/cancelamento de pedido de outro cliente (`PATCH/PUT/DELETE /api/orders/:id`) | `403 FORBIDDEN_ORDER_MODIFICATION` | `100/100` bloqueados com `403 FORBIDDEN_ORDER_MODIFICATION` | **PASS** |
| **08** | Acesso cruzado entre **3 estabelecimentos** (`est-forno-nobre-01`, `est-bella-napoli-002`, `est-don-luigi-003`) | Isolamento total de pedidos, catálogos e dashboards (`403`) | Admin/Cliente de uma pizzaria bloqueado (`403`) ao tentar ler/alterar outra | **PASS** |
| **09** | Manipulação de `establishment_id` ou uso de produto/cupom de outro estabelecimento no checkout | `400 CROSS_TENANT_ESTABLISHMENT_MISMATCH` | `400 CROSS_TENANT_ESTABLISHMENT_MISMATCH` | **PASS** |
| **10** | Tentativa de acesso a pedido por ID previsível ou código público (`PZ-9041`) sem token | `403 FORBIDDEN_ORDER_ACCESS` | `403 FORBIDDEN_ORDER_ACCESS` | **PASS** |
| **11** | Utilização indevida de `order_access_token` (token de outro pedido, `idempotency_key` como token ou token expirado) | `403 FORBIDDEN_ORDER_ACCESS` / `403 ORDER_ACCESS_TOKEN_EXPIRED` | `403 FORBIDDEN_ORDER_ACCESS` e `403 ORDER_ACCESS_TOKEN_EXPIRED` | **PASS** |
| **12** | Tentativa de acesso a `/api/admin/observability` por anônimo, `kitchen_operator` ou `establishment_admin` | `401` (anônimo) / `403 INSUFFICIENT_ADMIN_ROLE` (não-owner) | `401` e `403 INSUFFICIENT_ADMIN_ROLE`; `200` apenas para `platform_owner` | **PASS** |
| **13** | Tentativa de exposição/uso de `service_role` no cliente (`apikey: ...service_role...` e inspeção do HTML) | `403 SERVICE_ROLE_CLIENT_EXPOSURE_FORBIDDEN` e `0` ocorrências no HTML | `403` na API e `0` ocorrências em `public/index.html` | **PASS** |
| **14** | Tentativa de acesso direto às tabelas protegidas (`/rest/v1/orders`, `/api/db/customers`, `/api/internal/admin_users`) | `403 DIRECT_TABLE_ACCESS_FORBIDDEN` | `403 DIRECT_TABLE_ACCESS_FORBIDDEN` | **PASS** |
| **15** | Verificação de políticas RLS, `REVOKE ALL FROM anon, PUBLIC` e `SET search_path` na migration `0006` | Presentes e sintaticamente íntegros | Confirmados em `0006_argon4_security_rls_multitenant_hardening.sql` | **PASS** |
| **16** | Tentativa de falsificação de IP (`X-Forwarded-For` rotativo com `trustProxy=false`) | Servidor ignora IP falsificado e mantém contagem no IP real do socket | IP falsificado ignorado; bloqueio aplicado sobre o socket real | **PASS** |
| **17** | Tentativa de brute force administrativo (múltiplas falhas seguidas de autenticação) | `429 TOO_MANY_AUTH_ATTEMPTS` + cabeçalho `Retry-After` | `429 TOO_MANY_AUTH_ATTEMPTS` + `Retry-After` presente | **PASS** |
| **18** | Webhook com assinatura HMAC-SHA256 inválida e Webhook com timestamp antigo (ataque de replay de 2h atrás) | `401 INVALID_WEBHOOK_SIGNATURE` e `400 WEBHOOK_TIMESTAMP_EXPIRED_OR_REPLAY` | `401` e `400 WEBHOOK_TIMESTAMP_EXPIRED_OR_REPLAY` | **PASS** |
| **19** | Webhook duplicado (reenvio idêntico do mesmo evento assinado) | `200 OK` com `deduplicated: true, processed: 0` | `200 OK`, `deduplicated: true, processed: 0` | **PASS** |
| **20** | Requisição com payload JSON malformado ou estrutura de webhook inválida | `400 INVALID_JSON_PAYLOAD` / `400 INVALID_WEBHOOK_PAYLOAD` | `400 INVALID_JSON_PAYLOAD` e `400 INVALID_WEBHOOK_PAYLOAD` | **PASS** |
| **R01–R14** | **Regressão Funcional Completa (Missões 01 a 05 + Missão 02 Pedidos Reais + Missão 03 Concorrência 100 Clientes)** | `14/14` suítes anteriores passando sem alteração visual | **`16/16` suítes totais aprovadas (`0` falhas)** | **PASS** |

---

## 7. Diagnóstico Transparente sobre Multi-Tenancy Real e Pendências para Produção (Seções 6, 7 e 15)

### 7.1 O que já está pronto para Multi-Estabelecimento vs. O que falta para Multi-Tenant SaaS Completo
- **Já implementado e validado nesta Missão 04**:
  - Registro e isolamento de múltiplos estabelecimentos (`Argon4PizzeriaEngine.registerEstablishment` e `getTenant`) com separação estrita de produtos, sabores, adicionais, cupons, zonas de entrega e pedidos por `establishment_id`.
  - Unicidade composta `(establishment_id, idempotency_key)` e `(establishment_id, public_code)` tanto no SQLite quanto no PostgreSQL (`0006`).
  - Tokens administrativos com escopo `establishment_id` (impedindo que o administrador da Pizzaria A leia ou altere pedidos da Pizzaria B ou C) e papel `platform_owner` com visão global.
- **O que ainda falta para operação comercial Multi-Tenant SaaS completa (não escopo desta missão)**:
  1. Resolução dinâmica de tenant no frontend por subdomínio ou rota (`/:slug` -> `GET /api/catalog?establishment_id=...`) com carregamento dinâmico do catálogo via `fetch('/api/catalog')` na inicialização da vitrine.
  2. Persistência do cadastro de múltiplos estabelecimentos e seus respectivos cardápios diretamente no banco SQLite/PostgreSQL (atualmente o estabelecimento padrão vem do seed e novos estabelecimentos são registrados via `registerEstablishment` ou migrations SQL).
  3. Painel de autenticação multi-pizzaria integrado ao Supabase Auth (`auth.users` <-> `public.admin_users`) em ambiente PostgreSQL real.

### 7.2 Instruções para Executar os Testes
```bash
# Executar todas as 16 suítes automatizadas (Missões 01 a 05 + Missão 02 + Missão 03 + Missão 04 Adversarial):
npm test
# ou diretamente:
node --test tests/argon4-suite.mjs
```
