# RELATÓRIO TÉCNICO FINAL — ARGON 4: CARDÁPIO DIGITAL PROFISSIONAL PARA PIZZARIA E RESTAURANTE

## 1. Arquitetura Implementada
O sistema foi projetado e implementado seguindo os padrões **MenuAI Fullstack Architecture**, **Professional Restaurant Menu Design (`archetype: 'pizzeria'`)** e **UI/UX Pro Max** (Dark Stone `#141210`, Wood-Fired Ember Orange `#EA580C`, Basil Green `#16A34A`, `tabular-nums`, animações composite-only `<300ms`):

1. **Camada de Banco de Dados Relacional (`supabase/migrations/`)**:
   - `0001_argon4_pizzeria_schema.sql`: Define as **20 tabelas** exigidas (`establishments`, `admin_users`, `store_settings`, `categories`, `pizza_sizes`, `products`, `product_variations`, `pizza_flavors`, `product_addons`, `promotions`, `coupons`, `customers`, `customer_addresses`, `orders`, `order_items`, `payments`, `order_status_history`, `whatsapp_messages`, `campaign_attributions`, `tracking_events`) com integridade referencial, índices compostos e políticas Row Level Security (RLS).
   - `0002_argon4_transactional_rpc_and_seed.sql`: Implementa a stored procedure transacional `public.create_order_transactional(...)` em PL/pgSQL (`SECURITY DEFINER`), garantindo que cálculo de subtotal, regra de pizza meio a meio, taxa de entrega por bairro, validação de cupom, geração do pedido e proteção contra duplicidade (`idempotency_key`) ocorram atomicamente no servidor.
2. **Camada de Backend e Regras de Negócio (`server/src/`)**:
   - `server/src/domain/argon4Engine.mjs`: Motor transacional de cálculo de preços em centavos, regra de pizzas inteiras ou fracionadas (`1/2`, `1/3` com opção administrativa entre **Maior Valor** e **Média dos Sabores**), gerador de payload **EMV BRCode Pix Copia e Cola** com cálculo CRC16-CCITT (`0x1021`), fila de mensagens da **WhatsApp Cloud API** com token de fencing (`C-09`), retentativas exponenciais, deduplicação por etapa e verificação de assinatura HMAC SHA-256 (`X-Hub-Signature-256`), além do motor de atribuição First/Last Touch e eventos de conversão.
   - `server/src/index.mjs` & `server/src/start.mjs`: Servidor HTTP REST API com rate limiting por IP, autenticação administrativa Bearer RBAC e endpoints públicos, administrativos e de webhook.
3. **Camada de Frontend Mobile-First + Painel Administrativo (`argon4-pizzaria-cardapio.html`)**:
   - Experiência Mobile-First para consumidores vindos de Google Ads e Meta Ads, incluindo Hero administrável com fotografia de alta resolução, status em tempo real, seletor rápido de tamanhos, carrossel promocional horizontal (`snap-x`), navegação de categorias com Scroll-Spy, construtor visual SVG de Pizza Meio-a-Meio, sacola persistente (`localStorage`), checkout interno completo (Entrega com busca de taxa por bairro ou Retirada no balcão; Pix Direto com Copia e Cola, Dinheiro com cálculo de troco ou Cartão na entrega) e tela de acompanhamento do pedido.
   - Painel Administrativo separado em 5 módulos: **Pedidos & KDS/WhatsApp**, **Cardápio & Pizzas**, **Promoções & Cupons**, **Configurações & Pix**, e **Marketing Digital (GA4/GTM/Google Ads/Meta Pixel/CAPI/UTMs) + Suíte de Testes E2E**.

---

## 2. Endpoints da API Backend (`server/src/index.mjs`)

| Método | Endpoint | Permissão | Descrição |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/catalog` | Público | Retorna dados do estabelecimento, tamanhos, categorias, promoções, produtos, sabores e adicionais ativos sem expor segredos. |
| `POST` | `/api/cart/calculate` | Público | Recalcula no servidor o preço de cada item (incluindo meio-a-meio, massa, borda e adicionais), valida cupom e calcula taxa de entrega por bairro. |
| `POST` | `/api/orders` | Público (Idempotente) | Cria o pedido transacionalmente no banco exigindo `idempotency_key`, gera payload Pix, registra atribuição UTM/GCLID/FBCLID, dispara `purchase` e enfileira mensagens do WhatsApp. |
| `POST` | `/api/tracking/events` | Público | Registra eventos do funil (`page_view`, `view_item`, `add_to_cart`, `begin_checkout`, `purchase`) com deduplicação por `event_id` e envio para Meta CAPI respeitando LGPD. |
| `GET` | `/api/webhooks/whatsapp` | Meta Verify | Valida o desafio `hub.challenge` do webhook oficial da Meta mediante `WHATSAPP_VERIFY_TOKEN`. |
| `POST` | `/api/webhooks/whatsapp` | HMAC SHA-256 | Processa confirmações de entrega (`sent`, `delivered`, `read`, `failed`) assinadas com `X-Hub-Signature-256`. |
| `GET` | `/api/admin/dashboard` | Admin Bearer | Retorna todos os pedidos, fila de mensagens WhatsApp, eventos de rastreamento, atribuições de campanhas e configurações. |
| `PATCH` | `/api/admin/orders/status` | Admin Bearer | Atualiza o status do pedido no painel e dispara automaticamente a notificação correspondente da Etapa 2 a 6 no WhatsApp do cliente. |
| `POST` | `/api/admin/orders/confirm-payment` | Admin Bearer | Marca manualmente o pagamento (Pix, Dinheiro ou Cartão) como confirmado no painel administrativo. |

---

## 3. Instruções de Configuração das Integrações

### 3.1 WhatsApp Cloud API (Meta Business Platform)
1. Acesse o portal [Meta for Developers](https://developers.facebook.com/) e crie ou selecione um App do tipo **Business**.
2. Adicione o produto **WhatsApp** e copie o `Phone Number ID` (`WHATSAPP_PHONE_NUMBER_ID`) e o `WhatsApp Business Account ID` (`WHATSAPP_BUSINESS_ACCOUNT_ID`).
3. Gere um Token Permanente de Usuário do Sistema no Gerenciador de Negócios da Meta com as permissões `whatsapp_business_messaging` e `whatsapp_business_management` e configure em `WHATSAPP_ACCESS_TOKEN`.
4. Em **Configuração > Webhooks**, configure a URL `https://seu-dominio.com/api/webhooks/whatsapp` com o `WHATSAPP_VERIFY_TOKEN` e assine o campo `messages`.
5. **Comportamento Fail-Safe**: Enquanto `WHATSAPP_CLOUD_ENABLED=false` ou as credenciais não estiverem preenchidas, o sistema **não simula envios falsos** — ele grava o pedido normalmente no banco/painel e registra a mensagem na fila com status `not_configured` para auditoria transparente.

### 3.2 Google Analytics 4 (GA4), Google Tag Manager (GTM) e Google Ads
1. No Painel Administrativo (Aba **Marketing & Tracking**) ou no `.env`, informe:
   - `GA4 Measurement ID` (ex.: `G-FN9040PIZZA`)
   - `GTM Container ID` (ex.: `GTM-K8L9040`)
   - `Google Ads Conversion ID` (ex.: `AW-114904088`) e `Conversion Label`
2. Todos os 10 eventos padronizados de e-commerce (`page_view`, `view_item_list`, `view_item`, `add_to_cart`, `remove_from_cart`, `view_cart`, `begin_checkout`, `add_shipping_info`, `add_payment_info`, `purchase`) são empurrados na `window.dataLayer` com `currency: 'BRL'`, `transaction_id` único e `event_id` deduplicado.

### 3.3 Meta Pixel & Meta Conversions API (CAPI)
1. Configure o `Meta Pixel ID` no painel e o `META_CONVERSIONS_API_ACCESS_TOKEN` no ambiente do servidor.
2. O sistema dispara `PageView`, `ViewContent`, `AddToCart`, `InitiateCheckout`, `AddPaymentInfo` e `Purchase` compartilhando exatamente o mesmo `event_id` entre o navegador e o servidor para deduplicação oficial na Meta, além de preservar os parâmetros `fbclid`, `fbc` e `fbp`.

---

## 4. Procedimento para Executar Localmente e Publicar
```bash
# 1. Executar a suíte de testes automatizados (Node.js >= 18)
npm test

# 2. Iniciar o servidor de API REST
npm start
```
Para aplicar o banco de dados no Supabase, execute na ordem os arquivos `supabase/migrations/0001_argon4_pizzeria_schema.sql` e `supabase/migrations/0002_argon4_transactional_rpc_and_seed.sql` no SQL Editor ou via `supabase db push`.
