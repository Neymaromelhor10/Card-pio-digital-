# RELATÓRIO TÉCNICO — ARGON 4: MISSÃO 02 — REORGANIZAÇÃO COMPLETA DAS CATEGORIAS DO CARDÁPIO

## 1. Resumo Executivo da Missão 02
As categorias principais do cardápio digital foram reorganizadas cirurgicamente conforme especificado, removendo o filtro/seletor de quantidade de fatias (`4, 6, 8 e 12 fatias`) do topo da vitrine e substituindo a estrutura antiga pelas **cinco categorias principais exclusivas**:
1. **Pizzas Tradicionais** (`slug: 'pizzas-tradicionais'`)
2. **Pizzas Doces** (`slug: 'pizzas-doces'`)
3. **Brotos** (`slug: 'brotos'`)
4. **Combos** (`slug: 'combos'`)
5. **Bebidas** (`slug: 'bebidas'`)

O Hero cinematográfico em vídeo, o Carrossel Promocional (dimensões, imagens, espaçamentos, tipografia e comportamento), o modal de personalização de produtos, o carrinho, o checkout, os pagamentos (Pix, Dinheiro, Cartão), a integração WhatsApp Cloud API, o Painel Administrativo e o rastreamento (GA4, GTM, Google Ads, Meta Pixel/CAPI) permaneceram **100% inalterados**.

---

## 2. Arquivos Modificados e Criados na Missão 02
- `supabase/migrations/0003_argon4_category_reorganization.sql` *(Novo)*: Migration SQL incremental que cria a categoria `Brotos`, ordena e ativa exclusivamente as 5 categorias principais, transfere as pizzas salgadas de `Pizzas Especiais Forno a Lenha` para `Pizzas Tradicionais` e desativa da navegação pública as categorias antigas (`pizzas-especiais`, `porcoes-entradas`, `sobremesas`) preservando todos os produtos e o histórico de pedidos.
- `server/src/domain/argon4Engine.mjs` *(Modificado)*: Atualização da estrutura de categorias semente, reclassificação das pizzas salgadas especiais para `cat-tradicionais`, inclusão dos itens dedicados da categoria `cat-brotos` e preservação integral dos itens de sobremesa e corniccione no banco.
- `public/index.html` / `argon4-pizzaria-cardapio.html` *(Modificado)*: Remoção do seletor de quantidade de fatias (`#sizeSelectorBar`) como filtro de topo e atualização da barra de navegação e seções para exibir exclusivamente as 5 categorias principais.
- `tests/argon4-suite.mjs` *(Modificado)*: Inclusão da Suíte de Testes #6 validando todos os **11 critérios obrigatórios da Missão 02**.
- `RELATORIO_MISSAO_02_CATEGORIAS.md` *(Novo)*: Relatório técnico de auditoria antes/depois da reorganização.

---

## 3. Quantidade de Produtos Antes e Depois

| Métrica de Auditoria do Catálogo | Antes da Missão 02 | Depois da Missão 02 | Status de Integridade |
| :--- | :--- | :--- | :--- |
| **Categorias Ativas na Navegação Principal** | `7` categorias | **`5` categorias exclusivas** (`Pizzas Tradicionais`, `Pizzas Doces`, `Brotos`, `Combos`, `Bebidas`) | ✅ 100% conforme |
| **Filtro de Quantidade de Fatias (4/6/8/12F) no Topo** | Presente (`#sizeSelectorBar`) | **Removido da vitrine** (mantido apenas como atributo descritivo/comercial do produto) | ✅ 100% conforme |
| **Produtos Originais Preservados no Banco (`is_deleted: false`)** | `10` produtos | **`10` produtos originais preservados** (`0` excluídos) | ✅ Nenhum produto perdido |
| **Produtos Dedicados na Categoria `Brotos` (`cat-brotos`)** | `0` dedicados (dependiam do filtro 4F) | **`4` produtos de Broto (25cm)** cadastrados em `Brotos` | ✅ Categoria `Brotos` populada |
| **Total Geral de Produtos no Banco de Dados** | `10` registros | **`14` registros ativos no banco** (`12` exibidos nas 5 categorias + `2` preservados no acervo) | ✅ Integridade referencial total |

---

## 4. Relação dos Produtos Transferidos e Classificados nas 5 Categorias Principais

| ID do Produto | Nome do Produto | Categoria Anterior | Nova Categoria Principal | Preço Preservado |
| :--- | :--- | :--- | :--- | :--- |
| `prod-pepperoni-burrata` | Pepperoni Artisanal & Burrata Fresca | `Pizzas Especiais Forno a Lenha` (`cat-especiais`) | **1. Pizzas Tradicionais** (`cat-tradicionais`) | `R$ 72,90` (De `R$ 79,90`) |
| `prod-margherita-verace` | Margherita Verace DOP | `Pizzas Especiais Forno a Lenha` (`cat-especiais`) | **1. Pizzas Tradicionais** (`cat-tradicionais`) | `R$ 62,90` (De `R$ 68,90`) |
| `prod-calabresa-artesanal` | Calabresa Artesanal Acebolada | `Pizzas Tradicionais` (`cat-tradicionais`) | **1. Pizzas Tradicionais** (`cat-tradicionais`) | `R$ 56,90` (De `R$ 62,90`) |
| `prod-frango-catupiry` | Frango com Catupiry® Original Gratinado | `Pizzas Tradicionais` (`cat-tradicionais`) | **1. Pizzas Tradicionais** (`cat-tradicionais`) | `R$ 64,90` |
| `prod-choc-morango` | Chocolate Belga com Morangos Frescos | `Pizzas Doces Artesanais` (`cat-doces`) | **2. Pizzas Doces** (`cat-doces`) | `R$ 52,90` (De `R$ 58,90`) |
| `prod-broto-calabresa` | Broto Calabresa Artesanal Acebolada (25cm) | *(Modalidade Broto 4F)* | **3. Brotos** (`cat-brotos`) | `R$ 38,90` |
| `prod-broto-margherita` | Broto Margherita Verace DOP (25cm) | *(Modalidade Broto 4F)* | **3. Brotos** (`cat-brotos`) | `R$ 42,90` |
| `prod-broto-frango-catupiry` | Broto Frango com Catupiry® Original (25cm) | *(Modalidade Broto 4F)* | **3. Brotos** (`cat-brotos`) | `R$ 41,90` |
| `prod-broto-choc-morango` | Broto Doce Chocolate Belga com Morangos (25cm) | *(Modalidade Broto 4F)* | **3. Brotos** (`cat-brotos`) | `R$ 39,90` |
| `prod-combo-familia` | Combo Família: Pizza Grande + Broto Doce + Coca-Cola 2L | `Combos Promocionais` (`cat-combos`) | **4. Combos** (`cat-combos`) | `R$ 109,90` (De `R$ 135,90`) |
| `prod-coca-2l` | Coca-Cola Original 2 Litros (Garrafa Gelada) | `Bebidas Geladas` (`cat-bebidas`) | **5. Bebidas** (`cat-bebidas`) | `R$ 16,90` |
| `prod-heineken-longneck` | Cerveja Heineken Puro Malte Long Neck 330ml | `Bebidas Geladas` (`cat-bebidas`) | **5. Bebidas** (`cat-bebidas`) | `R$ 9,90` (De `R$ 11,90`) |

---

## 5. Relação dos Produtos Preservados sem Categoria Pública Adequada (Sobremesas e Cornicciones)
Conforme determinado na Seção 3 (*"Os produtos de Pizz & Cornicciones devem ser analisados individualmente... Os produtos de Sobremesas Individuais devem ser preservados. Como não haverá uma categoria de sobremesas nesta nova estrutura, identifique esses produtos no relatório e não os exclua nem os coloque artificialmente em outra categoria"*):

1. **`prod-tiramisu-artesanal` — Tiramisù Clássico Italiano no Pote (220g)**
   - **Categoria Original**: `Sobremesas Individuais` (`cat-sobremesas`)
   - **Preços e Dados**: `R$ 24,90` (`base_price_cents: 2490`), imagem, descrição e identificador 100% preservados (`is_deleted: false`).
   - **Motivo Técnico**: Trata-se de uma sobremesa individual de pote (não é pizza doce nem broto). Foi preservada integralmente no banco de dados e no Painel Administrativo sem ser forçada artificialmente em outra categoria pública.
2. **`prod-corniccione-parmesao` — Corniccione ao Alho Negro, Alecrim & Parmesão**
   - **Categoria Original**: `Entradas & Cornicciones` (`cat-porcoes`)
   - **Preços e Dados**: `R$ 27,90` (`base_price_cents: 3290`, `promotional_price_cents: 2790`), imagem, descrição e identificador 100% preservados (`is_deleted: false`).
   - **Motivo Técnico**: Analisado individualmente, trata-se de um aperitivo/entrada de massa fina temperada com azeite e alecrim para compartilhar (não é uma pizza tradicional recheada nem uma pizza broto). Foi preservado integralmente no banco de dados e no Painel Administrativo sem exclusão e sem classificação artificial.
