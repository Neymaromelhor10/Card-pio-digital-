# ARGON 4 — MISSÃO 16.1: RELATÓRIO DE CORREÇÃO CIRÚRGICA DE SEGURANÇA HTTP, LIMITAÇÃO DE MEMÓRIA E RATE LIMIT

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 16.1 — Correção Cirúrgica de Segurança HTTP, Limitação de Memória e Rate Limit  
**Backup Original Preservado:** `argon4-pizzaria-fullstack-backup-missao15.zip` (SHA-256: `c9795270db21dcf9b98e60edec929b68687d92b9265baa8be2fa9ff7ee8068be`)  
**Data:** 2026-11-18  
**Status da Missão 16.1:** **APROVADA** *(Todas as 27/27 suítes automatizadas e o teste real em Chromium Headless `390x844` foram aprovados sem falhas. A Missão 16.2 NÃO foi iniciada).*

---

## 1. Resumo Executivo

A Missão 16.1 corrigiu cirurgicamente os dois problemas identificados na auditoria independente sobre `server/src/index.mjs`:
1. **`M16-D01` — Acumulação de memória em `readRawBody` e retorno HTTP 413:**
   - **Antes:** `readRawBody(req)` concatenava strings (`data += chunk`) sem checar `Content-Length` antecipadamente, não liberava o buffer acumulado ao ultrapassar `1_000_000` bytes (continuava acumulando os chunks seguintes no listener `data` mesmo após rejeitar a Promise) e `mapErrorToHttpResponse` retornava HTTP `400` em vez de HTTP `413`.
   - **Depois:** `readRawBody(req, limitBytes = 1_000_000)` rejeita imediatamente se `Content-Length > 1_000_000` (drenando o stream sem alocar memória), contabiliza bytes reais (`Buffer.byteLength`), zera imediatamente os buffers acumulados (`chunks = null`) e ativa `discarding = true` no exato instante em que `totalBytes > 1_000_000`, garante resolução única (`settled = true`) com remoção limpa de listeners (`cleanup()`), mapeia `PAYLOAD_TOO_LARGE` para **HTTP `413 Payload Too Large`** com header `Connection: close` e protege `sendJson` contra respostas duplicadas (`if (res.headersSent || res.writableEnded) return;`).
2. **`M16-D02` — Crescimento ilimitado de `rateLimitBuckets`, `authFailureBuckets` e `revokedSessionJtis`:**
   - **Antes:** Os mapas de rate limit e o conjunto `revokedSessionJtis` acumulavam chaves de IPs, telefones e sessões revogadas sem varredura de expiração e sem limite máximo de entradas.
   - **Depois:** Implementada política determinística de limpeza de registros expirados (`pruneBucketMap`) + limite máximo configurável de entradas (`maxRateLimitEntries = 4096`, `maxAuthFailureEntries = 2048`, `maxRevokedSessionEntries = 2048`) com remoção LRU/FIFO das entradas mais antigas e migração de `revokedSessionJtis` para `Map<jti, expTimestampMs>`, removendo automaticamente tokens revogados cuja validade (`exp`) já expirou.

---

## 2. Lista de Arquivos Modificados

| Arquivo | Modificação Realizada na Missão 16.1 |
|---|---|
| `server/src/index.mjs` | Correção de `readRawBody` (descarte sem acumulação pós-1 MB, checagem de `Content-Length`, cleanup de listeners), mapeamento de `PAYLOAD_TOO_LARGE` para HTTP `413`, guarda contra resposta duplicada em `sendJson`, e política de limpeza por expiração + teto de memória (`pruneBucketMap`) para `rateLimitBuckets`, `authFailureBuckets` e `revokedSessionJtis`. |
| `tests/argon4-suite.mjs` | Adicionado **Subteste 27** validando todos os 12 cenários obrigatórios da Missão 16.1 em servidor HTTP Node.js e SQLite reais. |

---

## 3. Evidências dos Testes Executados (Subteste 27 e Regressão Completa)

| Cenário Obrigatório da Missão 16.1 | Tipo de Teste | Resultado Obtido |
|---|---|---|
| 1. Requisição normal abaixo de 1 MB (`POST /api/cart/calculate`) | **REAL (HTTP + Node.js)** | **PASSOU** (`200 OK`) |
| 2. Requisição exatamente no limite (`1.000.000` bytes UTF-8) | **REAL (HTTP + Node.js)** | **PASSOU** (`200 OK` — aceito sem falso positivo) |
| 3. Requisição acima de 1 MB (`1.000.001` bytes UTF-8) | **REAL (HTTP + Node.js)** | **PASSOU** (`413 Payload Too Large`, `error: "PAYLOAD_TOO_LARGE"`) |
| 4. Requisição muito acima do limite (`~12.5 MB` via chunked stream) | **REAL (HTTP Stream + Node.js)** | **PASSOU** (`413 Payload Too Large`, restante do stream descartado) |
| 5 e 6. Várias requisições excessivas simultâneas (`8 x 8.3 MB = ~67 MB` descartados) + verificação de memória heap | **REAL (HTTP Concorrente + `process.memoryUsage()`)** | **PASSOU** (todas receberam `413` e `heapDeltaMb < 20 MB`, provando que os 67 MB não foram acumulados) |
| 7 e 8. Milhares de IPs e escopos diferentes (`1.500` IPs distintos contra teto configurado de `500`) | **REAL (HTTP + Rate Limiter)** | **PASSOU** (`rateLimitBucketsSize <= 500`, sem crescimento ilimitado) |
| 9. Expiração e limpeza de buckets e sessões revogadas (`220` logouts contra teto `150` + expiração temporal) | **REAL (HTTP + Sessões HMAC)** | **PASSOU** (`revokedSessionJtisSize <= 150` durante pico e `0` após expiração) |
| 10. Preservação do bloqueio de brute force (`8` falhas `401` -> `9ª` tentativa bloqueada) | **REAL (HTTP + Auth RBAC)** | **PASSOU** (`429 Too Many Requests`) |
| 11 e 12. Preservação de idempotência, criação de pedidos e pagamentos sem regressão | **REAL (HTTP + SQLite ACID em disco)** | **PASSOU** (`201 Created` + replay idempotente `200 OK` + Subtestes 1–26 intactos) |

---

## 4. Separação Clara: Testes Reais vs Simulados vs Inspeções Estáticas

- **Testes Reais Executados (`npm test` Subtestes 1–16, 18–20, 25, 26, 27 + `run-browser-e2e-chromium.mjs`):**
  - Servidor HTTP Node.js real (`http.createServer`), streams TCP/HTTP chunked reais, banco de dados **SQLite 3.40.1 ACID em disco (WAL)** e navegador **Chromium Headless real (`390x844`)** via CDP (`27/27` suítes aprovadas em `23.34 s`, `0` falhas).
- **Testes Simulados (Mocks):**
  - Subtestes 17, 21, 22, 24 e os blocos de mock em 25/26 testam o contrato parametrizado do `PostgresOrderStore` usando dublês de `pg.Pool` em memória.
- **Inspeções Estáticas (`node scripts/verify-migrations-order.mjs` e `check-codespaces-env.mjs`):**
  - `9/9` migrations SQL (`0001`–`0009`) íntegras, transacionais e sem `DROP` destrutivo; `.devcontainer`, `.gitignore` e ausência de segredos expostos verificados.
- **Testes Externos Pendentes (`tests/postgres-integration-rls.mjs` e `npm run homolog:pg`):**
  - `SKIP` neste container offline (aguardando conexão com instância PostgreSQL/Supabase externa).

---

## 5. Hashes SHA-256

- **Backup Original da Missão 15 (`argon4-pizzaria-fullstack-backup-missao15.zip`):** `c9795270db21dcf9b98e60edec929b68687d92b9265baa8be2fa9ff7ee8068be`
- **ZIP Final da Missão 16.1 (`argon4-pizzaria-fullstack.zip`):** calculado e entregue abaixo.
