# RELATÓRIO TÉCNICO — ARGON 4: MISSÃO 02 — IMPLEMENTAÇÃO DO FLUXO REAL DE PEDIDOS (FRONTEND → BACKEND → BANCO DE DADOS)

## 1. Arquitetura Anterior vs. Arquitetura Posterior

| Camada / Aspecto | Arquitetura Anterior (Identificada na Auditoria — Missão 01) | Arquitetura Posterior (Implementada na Missão 02) |
| :--- | :--- | :--- |
| **Submissão no Checkout (`submitFinalOrder`)** | Criava objetos `newOrder` localmente no navegador (`db.orders.unshift`), inventava `orderId` e `publicCode` no cliente e gravava em `localStorage`. | Envia `POST /api/orders` com `fetch()`, `AbortController` (timeout de 15s) e cabeçalho `Idempotency-Key` gerado antes do primeiro envio. Nunca inventa IDs nem confirma pedido sem resposta `persisted: true` do backend. |
| **Persistência no Backend (`Argon4PizzeriaEngine`)** | Mantinha `this.state.orders = []` apenas na memória RAM do processo Node.js; reiniciar o servidor apagava todos os pedidos. | Persistência relacional transacional em disco via **SQLite 3 ACID (`server/src/db/sqliteOrderStore.mjs`)** com `PRAGMA foreign_keys = ON`, `PRAGMA journal_mode = WAL`, `PRAGMA synchronous = FULL` e transações atômicas `BEGIN IMMEDIATE ... COMMIT / ROLLBACK`, além da migration PostgreSQL `0004_argon4_transactional_orders_hardening.sql`. Os pedidos e itens sobrevivem integralmente ao reinício do servidor. |
| **Segurança Financeira e `create_order_transactional`** | A função SQL `0002` lia `v_item->>'verified_addons_cents'` do JSON e aplicava `GREATEST(quantity, 1)`. | A migration `0004` e o motor `Argon4PizzeriaEngine` ignoram qualquer preço/taxa/adicional vindo do cliente, consultam preços exclusivamente no catálogo oficial, validam quantidades inteiras em `1..50` e rejeitam bairros não autorizados (`UNAUTHORIZED_DELIVERY_NEIGHBORHOOD`). |
| **Idempotência e Concorrência** | Comparava apenas a string `idempotency_key`, aceitando silenciosamente payloads diferentes com a mesma chave ou devolvendo pedido de outro cliente. | Calcula `customer_scope_hash` (SHA-256 do estabelecimento + telefone normalizado) e `idempotency_payload_hash` (SHA-256 do payload canônico), serializa requisições concorrentes com mutex transacional + `UNIQUE(idempotency_key)` no banco e rejeita conflitos com `409 IDEMPOTENCY_PAYLOAD_CONFLICT` ou `409 IDEMPOTENCY_CROSS_CUSTOMER_CONFLICT`. |
| **Isolamento e Privacidade** | Sem endpoint isolado por token de pedido; reutilização de chave podia expor dados de outro pedido. | Gera `order_access_token` criptográfico (24 bytes hex) por pedido, grava apenas `access_token_hash` (SHA-256) no banco e exige `X-Order-Access-Token` (ou `Bearer` admin) em `GET /api/orders/:id`, bloqueando acessos cruzados ou sem token com `403 FORBIDDEN_ORDER_ACCESS`. |
| **Estados do Pedido e Outbox WhatsApp** | Misturava recebimento com memória local. | Distingue `received`, `persisted` (`persistence_status: 'persisted'`) e `whatsapp_status` (`not_configured`, `queued_outbox`, `sent`, `failed`) na tabela persistente `whatsapp_outbox`, sem simular envio quando não configurado e sem perder o pedido se o WhatsApp falhar. |

---

## 2. Arquivos Modificados e Criados
1. `supabase/migrations/0004_argon4_transactional_orders_hardening.sql` *(Novo)*:
   - Migration incremental que corrige `public.create_order_transactional` (eliminando o uso de `verified_addons_cents` enviado pelo cliente e calculando preços de sabores, massas, bordas e adicionais diretamente das tabelas do banco), adiciona `idempotency_payload_hash`, `customer_scope_hash`, `access_token_hash`, `persistence_status`, `whatsapp_status`, `pricing_snapshot`, constraint `chk_order_items_quantity_bounds (1..50)` e cria a tabela `public.whatsapp_outbox`.
2. `server/src/db/sqliteOrderStore.mjs` *(Novo)*:
   - Repositório relacional SQLite 3 ACID em disco com tabelas `orders`, `order_items`, `payments`, `order_status_history`, `whatsapp_outbox`, `campaign_attributions`, `tracking_events` e `coupons_usage`, garantindo atomicidade transacional (`BEGIN IMMEDIATE ... COMMIT / ROLLBACK`) e sobrevivência ao reinício do processo Node.js.
3. `server/src/domain/argon4Engine.mjs` *(Modificado)*:
   - Integração com `SqliteOrderStore`, mutex transacional para requisições simultâneas, validação financeira e de limites (`quantity` inteira entre `1` e `50`, bairros ativos autorizados), validação de `customer_scope_hash` e `idempotency_payload_hash`, isolamento via `getOrderForCustomer` e persistência de `whatsapp_outbox`.
4. `server/src/index.mjs` *(Modificado)*:
   - Servimento estático de `public/index.html`, suporte ao header `Idempotency-Key` em `POST /api/orders`, novo endpoint isolado `GET /api/orders/:id` protegido por `X-Order-Access-Token` (ou `Bearer` Admin) e mapeamento seguro de erros HTTP (`400`, `401`, `403`, `404`, `409`, `503`) sem vazar stack traces ou dados sensíveis.
5. `server/src/start.mjs` *(Modificado)*:
   - Inicialização do servidor conectada ao banco persistente em disco (`data/argon4-orders.sqlite` ou `ARGON4_SQLITE_PATH`).
6. `public/index.html` & `artifacts/file_generation/ttl=63d/intermediate/argon4-pizzaria-cardapio.html` *(Modificados)*:
   - `submitFinalOrder()` envia `POST /api/orders` ao backend com `idempotency_key` gerada antes do primeiro envio e mantida estável durante retries da mesma operação lógica; removida a criação local de pedidos em `localStorage`; exibição fiel de `persistence_status` e `whatsapp_status` somente após confirmação real do servidor.
7. `tests/argon4-suite.mjs` *(Modificado)*:
   - Ampliação para **11 suítes completas de testes automatizados** cobrindo fluxo normal, persistência após reinício do servidor, atomicidade transacional (`ROLLBACK`), idempotência, concorrência, conflito de payload/cliente, integridade financeira e isolamento de acesso.

---

## 3. Endpoints Criados ou Modificados
- `POST /api/orders`: Recebe o payload do checkout (e cabeçalho `Idempotency-Key`), valida integralmente os itens, recalcula todos os valores no servidor, grava atomicamente em transação no banco de dados e retorna `201 Created` (novo pedido) ou `200 OK` (`idempotent_replay: true`), ou `409 Conflict` em caso de conflito de idempotência.
- `GET /api/orders/:id`: Consulta um pedido persistido por `id` ou `public_code`, exigindo obrigatoriamente o cabeçalho `X-Order-Access-Token` correspondente ao pedido (ou `Authorization: Bearer <ADMIN_API_TOKEN>`), retornando `403 FORBIDDEN_ORDER_ACCESS` para qualquer tentativa sem token válido ou com chave de idempotência.
- `GET /` (e ativos estáticos em `public/`): Serve o cardápio digital integrado diretamente à API do mesmo servidor.

---

## 4. Testes Automatizados Executados e Resultados Reais (`11/11 PASS`)
1. **Fluxo Normal**: Criação via `POST /api/orders`, persistência no banco SQLite, recuperação dos itens associados, conferência de valores/snapshots e recuperação completa após fechar o servidor e iniciar uma nova instância do servidor/motor sobre o mesmo arquivo de banco em disco.
2. **Idempotência e Concorrência**: Duplo clique, requisições simultâneas (`Promise.all`) gerando apenas 1 pedido, retry após timeout/perda de resposta recuperando o mesmo pedido (`idempotent_replay: true`), rejeição de mesma chave com payload diferente (`409 IDEMPOTENCY_PAYLOAD_CONFLICT`) e rejeição de mesma chave por outro cliente (`409 IDEMPOTENCY_CROSS_CUSTOMER_CONFLICT`).
3. **Integridade e Transação Atômica**: Rejeição de quantidade `0`, negativa (`-5`), fracionária (`1.5`) e excessiva (`51` / `999`), produto inexistente, borda/adicional inexistente, bairro não autorizado, dados incompletos, tentativa de adulteração de preços/taxas/adicionais e teste de falha no meio da gravação do 2º item comprovando `ROLLBACK` total (zero pedidos parciais no banco).
4. **Isolamento e Privacidade**: Pedidos e itens independentes, bloqueio `403 FORBIDDEN_ORDER_ACCESS` ao tentar consultar pedido de terceiro por `id`, `public_code`, token de outro pedido ou `idempotency_key`.

---

## 5. Pendências e Instruções para Executar o Ambiente de Homologação
- **Transparência sobre PostgreSQL vs. SQLite Homologação Local**: Neste container de build offline não há instância do servidor PostgreSQL (`psql`) em execução nem acesso de rede externo para o Supabase Cloud. Por isso, a persistência transacional real nos testes automatizados e no servidor local é executada pelo motor relacional **SQLite 3.40.1 ACID** (`server/src/db/sqliteOrderStore.mjs`) em disco, enquanto a migration PostgreSQL corrigida (`supabase/migrations/0004_argon4_transactional_orders_hardening.sql`) está pronta para aplicação no banco Supabase/PostgreSQL de staging/produção.
- **Como executar em homologação**:
  ```bash
  # 1. Executar toda a bateria de testes automatizados (usa bancos SQLite isolados por teste):
  npm test

  # 2. Iniciar o servidor HTTP + Banco SQLite persistente em data/argon4-orders.sqlite:
  npm start
  # Acesse http://localhost:3000
  ```
