# RELATÓRIO TÉCNICO — ARGON 4: MISSÃO 06 — FINALIZAÇÃO DO CARDÁPIO DIGITAL PARA UMA ÚNICA PIZZARIA

## 1. Resumo Executivo e Separação de Status (Seção 13)
Esta missão finalizou o produto original para operação de **uma única pizzaria** (`est-forno-nobre-01`), migrando o catálogo e as configurações comerciais (`establishment`, `store_settings`, `categories`, `products`, `pizza_sizes`, `pizza_flavors`, `product_addons`, `coupons`) para persistência real em banco de dados, integrando o cardápio público (`GET /api/catalog`) e os endpoints administrativos autenticados (`/api/admin/categories`, `/api/admin/products`, `/api/admin/pizza-sizes`, `/api/admin/pizza-flavors`, `/api/admin/addons`, `/api/admin/coupons`, `/api/admin/settings`) e validando **20 testes funcionais obrigatórios** + toda a regressão anterior (`18/18` suítes aprovadas, `0` falhas).

### Classificação Transparente
- **Implementado**:
  - Persistência relacional completa do catálogo e configurações comerciais em `SqliteOrderStore` (desenvolvimento/homologação local) e `PostgresOrderStore` (staging/produção).
  - Migration incremental `0008_argon4_single_pizzeria_catalog_persistence.sql` preservando todas as migrations `0001`–`0007`.
  - Endpoints administrativos protegidos por RBAC (`platform_owner` e `establishment_admin`; `kitchen_operator` bloqueado com `403`).
  - Carregamento dinâmico do cardápio público via `hydratePublicCatalogFromBackend()` (`GET /api/catalog`), exibindo apenas categorias ativas e produtos disponíveis e não excluídos.
  - Exclusão segura de produtos com histórico de pedidos via soft delete (`is_deleted = true`), preservando integralmente os valores históricos de pedidos já realizados.
- **Testado com banco real (SQLite 3.40.1 ACID em disco)**:
  - Todos os **20 testes funcionais obrigatórios** (Subteste 18) e toda a regressão de pedidos, concorrência, idempotência, checkout sem CEP e segurança (`18/18` suítes aprovadas).
- **Testado com mocks**:
  - Contrato transacional parametrizado de `PostgresOrderStore` (Subteste 17) utilizando mock de `pg.Pool`.
- **Pendente / Bloqueador de Produção**:
  - Execução ao vivo contra PostgreSQL/Supabase (`npm run homolog:pg` e `npm run test:pg:rls`), pois este container offline não dispõe de daemon PostgreSQL nem do pacote `pg` instalado; transporte definitivo da WhatsApp Cloud API e pagamento real (excluídos desta missão).

---

## 2. Arquivos Modificados e Criados
- `supabase/migrations/0008_argon4_single_pizzeria_catalog_persistence.sql` *(Novo — colunas e índices de catálogo sem alterar histórico)*
- `server/src/db/sqliteOrderStore.mjs` *(Modificado — tabelas relacionais `establishment_config`, `categories`, `pizza_sizes`, `products`, `pizza_flavors`, `product_addons`, `coupons` e CRUD transacional)*
- `server/src/db/postgresOrderStore.mjs` *(Modificado — métodos parametrizados de CRUD de catálogo e configurações)*
- `server/src/domain/argon4Engine.mjs` *(Modificado — seed inicial no banco, carregamento do banco na inicialização, bloqueio de compra em categoria desativada e métodos validados de CRUD)*
- `server/src/index.mjs` *(Modificado — filtro de vitrine pública em `GET /api/catalog` e rotas autenticadas `/api/admin/catalog`, `/api/admin/categories*`, `/api/admin/products*`, `/api/admin/pizza-sizes`, `/api/admin/pizza-flavors`, `/api/admin/addons`, `/api/admin/coupons`, `/api/admin/settings`)*
- `public/index.html` & `artifacts/file_generation/ttl=63d/intermediate/argon4-pizzaria-cardapio.html` *(Modificados — `hydratePublicCatalogFromBackend()` e chamadas reais de admin para produtos)*
- `scripts/verify-migrations-order.mjs` *(Modificado — validação sequencial `0001`–`0008`)*
- `tests/argon4-suite.mjs` *(Modificado — adição do Subteste 18 com os 20 testes funcionais obrigatórios)*
- `RELATORIO_MISSAO_06_CARDAPIO_UNICA_PIZZARIA.md` *(Novo — Relatório Técnico)*

---

## 3. Resultados dos 20 Testes Funcionais Obrigatórios (Subteste 18 — `18/18 PASS`)
1. **Criar categoria**: `POST /api/admin/categories` — **PASS**.
2. **Editar categoria**: Atualização de nome e `sort_order` — **PASS**.
3. **Desativar categoria**: `is_active: false` oculta do `GET /api/catalog` e impede compra — **PASS**.
4. **Criar produto**: `POST /api/admin/products` — **PASS**.
5. **Editar produto**: Atualização de nome, descrição e imagem — **PASS**.
6. **Alterar preço**: Atualização de `base_price_cents` (`7990` → `8490`) — **PASS**.
7. **Desativar produto**: `is_available: false` oculto do cardápio público — **PASS**.
8. **Criar tamanho**: `POST /api/admin/pizza-sizes` (`Gigante 16 fatias`) — **PASS**.
9. **Criar sabor**: `POST /api/admin/pizza-flavors` (`Trufada Premium`) — **PASS**.
10. **Criar adicional**: `POST /api/admin/addons` (`Burrata Inteira Extra`) — **PASS**.
11. **Criar borda**: `POST /api/admin/addons` (`Borda Recheada Provolone`) — **PASS**.
12. **Carregar catálogo público**: `GET /api/catalog` retorna apenas itens ativos sem vazar `pix_key` — **PASS**.
13. **Reiniciar servidor e verificar persistência**: Nova instância sobre o mesmo arquivo SQLite recupera todas as alterações de catálogo e configurações — **PASS**.
14. **Tentar comprar produto desativado**: Rejeitado com `HTTP 400` — **PASS**.
15. **Tentar comprar produto inexistente**: Rejeitado com `HTTP 400` — **PASS**.
16. **Enviar preço adulterado pelo frontend**: `unit_price_cents: 1` ignorado; cobrado `R$ 121,80` + entrega `R$ 8,00` = `R$ 129,80` — **PASS**.
17. **Testar pizza meio a meio**: Novo sabor + sabor existente + nova borda + novo adicional calculados no servidor — **PASS**.
18. **Testar imagens**: URL persistida e retornada pelo banco após reinício — **PASS**.
19. **Testar falhas de persistência**: Categoria inexistente rejeitada com `400 CATEGORY_NOT_FOUND` sem falso sucesso — **PASS**.
20. **Testar permissões administrativas**: Anônimo rejeitado com `401`; `kitchen_operator` bloqueado com `403` — **PASS**.

---

## 4. Instruções de Execução
```bash
# 1. Verificar ordem das migrations (0001–0008):
npm run verify:migrations

# 2. Executar todas as 18 suítes de testes (incluindo os 20 testes da Missão 06):
npm test

# 3. Iniciar o servidor local (SQLite persistente em data/argon4-orders.sqlite):
npm start
```
