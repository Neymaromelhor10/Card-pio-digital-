# ARGON 4 — MISSÃO 12: RELATÓRIO DE PREPARAÇÃO DO AMBIENTE REAL DE HOMOLOGAÇÃO — GITHUB CODESPACES E SUPABASE

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 12 — Preparação do Ambiente Real de Homologação (GitHub Codespaces e Supabase)  
**Backup Original Preservado:** `argon4-pizzaria-fullstack-backup-missao11.zip` (SHA-256: `ec951252bd4706b2a9da659dab6d5896117eb2fed7bbeb52f6b79477efa856c5`)  
**Data:** 2026-11-17  
**Classificação Final de Prontidão:** **PREPARADA PARA HOMOLOGAÇÃO NO GITHUB CODESPACES E SUPABASE** *(PostgreSQL real não declarado homologado pois este container é offline, sem acesso ao registry npm e sem instância Supabase conectada).*

---

## 1. Resumo Executivo

A Missão 12 auditou e preparou integralmente o projeto para ser aberto, instalado e homologado em um **GitHub Codespace limpo** (inclusive pelo navegador mobile Android) conectado a um projeto **Supabase de homologação**:
1. Criado `.devcontainer/devcontainer.json` oficial com imagem Node.js 20, encaminhamento automático da porta `3000`, `postCreateCommand: "npm install"`, `postStartCommand: "node scripts/check-codespaces-env.mjs"` e declaração dos Secrets (`DATABASE_URL`, `ADMIN_API_TOKEN`, `SESSION_SECRET`).
2. Criado `server/src/envLoader.mjs` (zero dependências externas) integrado a `start.mjs`, `run-postgres-homologation.mjs` e `postgres-integration-rls.mjs`, permitindo usar tanto Codespaces Secrets quanto arquivo `.env` local (com precedência para variáveis já injetadas no ambiente).
3. Criado `scripts/check-codespaces-env.mjs` (`npm run check:env`), que valida Node.js, `package-lock.json`, pacote `pg`, migrations `0001`–`0009`, URL encaminhada do Codespaces (`https://<codespace>-3000.app.github.dev`) e status das variáveis de ambiente **sem exibir nenhum segredo**.
4. Criado `GUIA_CODESPACES_E_SUPABASE_MOBILE.md` com instruções passo a passo voltadas para uso pelo celular Android.

---

## 2. Lista de Arquivos Criados e Modificados

| Arquivo | Ação | Descrição Técnica |
|---|---|---|
| `.devcontainer/devcontainer.json` | Criado | Configuração do GitHub Codespaces (Node 20, porta `3000`, `npm install` automático e Secrets declarados). |
| `server/src/envLoader.mjs` | Criado | Carregador seguro de `.env` local sem dependências externas e sem sobrescrever Secrets do Codespaces. |
| `scripts/check-codespaces-env.mjs` | Criado | Diagnóstico de prontidão (`npm run check:env`) com saída JSON higienizada (zero vazamento de credenciais). |
| `GUIA_CODESPACES_E_SUPABASE_MOBILE.md` | Criado | Guia prático passo a passo em português para GitHub Codespaces + Supabase pelo celular Android. |
| `package.json` | Modificado | Adicionados scripts `"check:env"` e `"test:e2e:browser"` junto a `"start"`, `"test"`, `"verify:migrations"`, `"homolog:pg"` e `"test:pg:rls"`. |
| `server/src/start.mjs` | Modificado | Integrado `loadDotEnvIfPresent()` antes da resolução do driver e verificação *fail-closed*. |
| `scripts/run-postgres-homologation.mjs` | Modificado | Integrado `loadDotEnvIfPresent()` para leitura automática de `.env` local no Codespaces. |
| `tests/postgres-integration-rls.mjs` | Modificado | Integrado `loadDotEnvIfPresent()` antes da checagem de `DATABASE_URL`. |
| `tests/argon4-suite.mjs` | Modificado | Adicionado **Subteste 23** validando `.devcontainer`, `package.json`, `loadDotEnvIfPresent` e documentação mobile. |

---

## 3. Situação do `package-lock.json` e das Dependências

- **Ambiente atual:** Node.js `v18.20.4`, npm `9.2.0`, container sandbox **sem acesso à internet** (`ENOTFOUND registry.npmjs.org`).
- **Dependências declaradas em `package.json`:** `"pg": "^8.13.1"` (única dependência externa de produção; todo o restante usa módulos nativos do Node.js).
- **Situação do `package-lock.json`:** **NÃO GERADO NESTE CONTAINER OFFLINE** (em cumprimento estrito à Regra 3: nenhum lockfile artificial foi fabricado). Assim que o repositório for aberto no GitHub Codespaces, o `postCreateCommand` (`npm install`) gerará o `package-lock.json` legítimo a partir do registry oficial do npm, permitindo rodar `npm ci` em seguida.

---

## 4. Situação da Configuração do GitHub Codespaces e da Integração Supabase

### 4.1 GitHub Codespaces
- `.devcontainer/devcontainer.json` configurado para encaminhar a porta `3000` com visibilidade `private`.
- O frontend (`public/index.html`) realiza todas as chamadas HTTP usando caminhos relativos (`/api/catalog`, `/api/orders`, `/api/admin/*`), funcionando nativamente tanto em `http://localhost:3000` quanto na URL encaminhada `https://<codespace>-3000.app.github.dev` sem erros de CORS.

### 4.2 Integração Supabase (`0001`–`0009`)
- **Migrations `0001` a `0009`:** verificadas por `npm run verify:migrations` (`9/9` íntegras, transacionais, sem `DROP` destrutivo).
- **Extensão exigida:** `pgcrypto` (`CREATE EXTENSION IF NOT EXISTS "pgcrypto"` na Migration `0001`, habilitada nativamente no Supabase).
- **UUID v5 e IDs externos:** `toPgUuid(rawId)` converte slugs textuais em UUID v5 RFC 4122 (`SHA-1`) determinístico e preserva o ID original em `external_id TEXT` (Migration `0009`).
- **Session & Transaction Pooler + TLS:** queries 100% posicionais (`$1..$N`) sem prepared statements nomeados, SSL com `rejectUnauthorized: true` e timeouts configuráveis.

---

## 5. Resultado dos 12 Testes Obrigatórios (Separação Rigorosa por Tipo)

| # | Verificação Obrigatória | Tipo de Evidência | Status | Resultado Obtido |
|---|---|---|---|---|
| 1 | Instalação limpa das dependências (`npm install` / `npm ci`) | Ambiente Externo (Registry npm) | **PENDENTE (Offline)** | Sem internet no container; configurado em `postCreateCommand` do Codespaces. |
| 2 | Verificação do lockfile (`package-lock.json`) | Inspeção Estática | **PENDENTE (Offline)** | Não fabricado artificialmente; será gerado pelo `npm install` real no Codespaces. |
| 3 | Testes automatizados completos (`npm test`) | **REAL (SQLite + HTTP)** + **MOCK (`pg.Pool`)** | **APROVADO** | **23/23 suítes aprovadas (`0` falhas)** em `19.428 ms`. |
| 4 | Inicialização SQLite (`SqliteOrderStore` WAL) | **REAL (SQLite 3.40.1 em disco)** | **APROVADO** | Validado nos Subtestes 1 a 16 e 18 a 20. |
| 5 | Inicialização do servidor HTTP (`createArgon4HttpServer`) | **REAL (Servidor HTTP Node.js)** | **APROVADO** | Validado nos Subtestes 5, 15, 18, 19, 20, 21 e Chromium E2E. |
| 6 | Endpoint `GET /api/health` | **REAL (HTTP + SQLite)** | **APROVADO** | Retorna `200 OK` (`status: "healthy"`) sem expor caminhos ou segredos (Subteste 21). |
| 7 | Carregamento do catálogo (`GET /api/catalog`) | **REAL (HTTP + SQLite + Chromium)** | **APROVADO** | 5 categorias ativas e produtos hidratados sem erro. |
| 8 | Checkout sem CEP e persistência de pedidos (`POST /api/orders`) | **REAL (HTTP + SQLite + Chromium)** | **APROVADO** | Pedido `#PZ-9041` criado, recalculado no servidor e persistido após restart. |
| 9 | Painel administrativo e transições de status | **REAL (HTTP + SQLite + Chromium)** | **APROVADO** | Autenticação HMAC-SHA256, atualização para `confirmed` e histórico persistido. |
| 10 | Testes Chromium em `390x844` (`npm run test:e2e:browser`) | **REAL (Chromium Headless + CDP)** | **APROVADO** | `innerWidth: 390`, `innerHeight: 844`, `scrollWidth: 390`, `js_errors: 0`, `local_resource_failures: 0`. |
| 11 | Verificação de segredos e `.gitignore` (`npm run check:env`) | **Inspeção Estática + Execução Real** | **APROVADO** | `.gitignore` protege `.env` e `*.sqlite*`; zero segredos em `public/index.html` e nos relatórios. |
| 12 | Scripts de homologação PostgreSQL (`homolog:pg` e `test:pg:rls`) | **Inspeção + Execução Condicional** | **PREPARADOS (SKIP Offline)** | Scripts validados; execução contra banco real aguarda `DATABASE_URL` no Codespaces. |

---

## 6. Pendências que Dependem do Usuário (No Celular / Codespaces)

1. Subir a pasta `argon4-pizzaria-fullstack` para o GitHub e abrir um **Codespace**.
2. Criar um projeto exclusivo de **homologação** no Supabase e copiar a `DATABASE_URL`.
3. Configurar `DATABASE_URL`, `ADMIN_API_TOKEN` e `SESSION_SECRET` nos Secrets do Codespaces (ou no `.env` local) e rodar os comandos abaixo.

---

## 7. Comandos Exatos para Continuar no GitHub Codespaces

```bash
# 1. Instalar dependência `pg` real, gerar package-lock.json legítimo e validar npm ci
npm install
npm ci

# 2. Verificar diagnóstico do ambiente (sem expor segredos)
npm run check:env

# 3. Validar ordem das 9 migrations (0001 a 0009)
npm run verify:migrations

# 4. Executar homologação real no PostgreSQL/Supabase (15 etapas + ondas de 10/25/50/100 clientes)
export DATABASE_DRIVER=postgres
npm run homolog:pg

# 5. Executar validação dinâmica de RLS (anon, authenticated, service_role e auditoria de conexão)
npm run test:pg:rls

# 6. Rodar regressão completa e iniciar o servidor na porta 3000
npm test
npm start
```
