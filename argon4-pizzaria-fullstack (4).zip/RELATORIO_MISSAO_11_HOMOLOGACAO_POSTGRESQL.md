# ARGON 4 — MISSÃO 11: RELATÓRIO DE PREPARAÇÃO E EXECUÇÃO DA HOMOLOGAÇÃO REAL POSTGRESQL/SUPABASE

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 11 — Preparação e Execução da Homologação Real PostgreSQL/Supabase  
**Backup Original Preservado:** `argon4-pizzaria-fullstack-backup-missao10.zip` (SHA-256: `6ce249f4fd1b1f0f25a36b0a32724ca6f45116c4854728022b4bc9d065587ee4`)  
**Data:** 2026-11-17  
**Classificação Final de Prontidão:** **PREPARADA PARA HOMOLOGAÇÃO** *(Como este container é isolado sem acesso à internet, sem registry npm e sem instância PostgreSQL/Supabase ativa, nenhum teste simulado foi transformado em homologação PostgreSQL real. Produção NÃO liberada nesta missão).*

---

## 1. Resumo Executivo

A Missão 11 reexaminou integralmente a implementação de `toPgUuid(rawId)`, a dependência `pg` e o lockfile, os scripts de homologação PostgreSQL (15 etapas obrigatórias), os 4 contextos de segurança de RLS (`anon`, `authenticated`, `service_role` e conexão privilegiada do backend), os artefatos de deploy e toda a regressão funcional ponta a ponta.

Três aprimoramentos técnicos foram realizados:
1. **`toPgUuid(rawId)` migrado para RFC 4122 UUID v5 estrito (`SHA-1`)** com namespace fixo e documentado (`ARGON4_UUID_V5_NAMESPACE = "a404f090-0001-4000-8000-010203040506"`), validado contra o vetor oficial da RFC 4122 (`DNS + "python.org" -> 886313e1-3b8a-5372-9b90-0c9aee199e5d`).
2. **`scripts/run-postgres-homologation.mjs` expandido** para executar na íntegra as **15 etapas obrigatórias** da Seção 4 contra o PostgreSQL real assim que `DATABASE_URL` for fornecida no Codespaces.
3. **`tests/postgres-integration-rls.mjs` expandido** para auditar separadamente `anon`, `authenticated`, `service_role` e a **conexão privilegiada do backend (`rolbypassrls`)**, documentando e validando a obrigatoriedade do controle de autorização HTTP no servidor Node.js.

---

## 2. Lista de Arquivos Modificados

| Arquivo | Alteração Realizada na Missão 11 |
|---|---|
| `server/src/db/postgresOrderStore.mjs` | Implementado RFC 4122 UUID v5 estrito (`SHA-1` sobre `16 bytes` binários de `ARGON4_UUID_V5_NAMESPACE` + bytes UTF-8 do ID, bits de versão `0101` no octeto 6 e variante `10xx` no octeto 8). |
| `scripts/run-postgres-homologation.mjs` | Expandido para cobrir todas as 15 etapas obrigatórias da Seção 4 (migrations `0001`–`0009`, seed concorrente, loadAll, edição admin + restart + 2º seed sem sobrescrever, rollback, pedido + idempotência + status, 4 ondas de concorrência e integridade de FKs). |
| `tests/postgres-integration-rls.mjs` | Expandido para testar `anon`, `authenticated` (owner vs kitchen), `service_role` e auditar `rolsuper`/`rolbypassrls` da conexão do backend. |
| `tests/argon4-suite.mjs` | Adicionado **Subteste 22** validando o vetor oficial RFC 4122 UUID v5, bits de versão/variante em todos os IDs do domínio e simulação stateful de preservação de alterações administrativas após restart e segundo seed. |

---

## 3. Falhas Encontradas e Correções

| ID | Componente | Falha Encontrada na Auditoria da Missão 11 | Correção Aplicada |
|---|---|---|---|
| **M11-F01** | `toPgUuid(rawId)` | A versão da Missão 09 utilizava `SHA-256` truncado com prefixo textual `"argon4:uuid:"`, o que era determinístico mas **não** seguia o padrão RFC 4122 Seção 4.3 (que exige `SHA-1` sobre os 16 bytes binários de um UUID de namespace + bytes UTF-8 do nome). | Substituído por implementação RFC 4122 UUID v5 exata com `ARGON4_UUID_V5_NAMESPACE = "a404f090-0001-4000-8000-010203040506"` e comprovado com vetor oficial da RFC 4122 no Subteste 22. |
| **M11-F02** | `scripts/run-postgres-homologation.mjs` | O script anterior não testava o ciclo completo de edição administrativa seguida de `store.close()`, nova instância e segunda chamada a `seedCatalogIfEmpty()` para provar em banco real que preços editados não são sobrescritos. | Adicionadas todas as 15 etapas sequenciais no script de homologação. |
| **M11-F03** | `tests/postgres-integration-rls.mjs` | Faltava verificação explícita de tentativa de `UPDATE public.products` por `anon`, `UPDATE public.store_settings` cruzado por `authenticated` e inspeção de `pg_roles` (`rolbypassrls`) da conexão do pool. | Adicionadas as asserções e o relatório de auditoria da conexão do backend. |

---

## 4. Resultado da Auditoria de UUID, Migrations, Seed, RLS, Pool e Segurança

### 4.1 Resultado dos Testes de UUID (`toPgUuid`)
- **Algoritmo:** RFC 4122 UUID v5 (`SHA-1` sobre `16 bytes` de `ARGON4_UUID_V5_NAMESPACE` + UTF-8).
- **Vetor Oficial RFC 4122:** `toPgUuid('python.org', '6ba7b810-9dad-11d1-80b4-00c04fd430c8') === '886313e1-3b8a-5372-9b90-0c9aee199e5d'` (**PASSOU**).
- **Determinismo e Preservação:** `est-forno-nobre-01` gera sempre `be2cb127-dc15-5b49-8383-0e0fa05e4e2a` (versão `5`, variante `8`), UUIDs já válidos são mantidos intactos e o ID original é preservado na coluna `external_id`.

### 4.2 Situação da Dependência `pg` e `package-lock.json`
- `package.json` declara `"pg": "^8.13.1"` e `"engines": { "node": ">=18.0.0" }`.
- Como este ambiente sandbox **não possui acesso à internet**, o comando `npm install` não pode baixar pacotes do registry npm; seguindo a Regra 3, **nenhum `package-lock.json` artificial foi forjado**. O procedimento exato para gerar e versionar o lockfile real no GitHub Codespaces está documentado na Seção 7.

### 4.3 Aplicação das Migrations (`0001`–`0009`)
- **Verificação Estrutural (`node scripts/verify-migrations-order.mjs`):** **9/9 migrations aprovadas** (`0001` a `0009`), transacionais (`BEGIN`/`COMMIT`) e sem `DROP` destrutivo.
- **Aplicação em PostgreSQL Real:** **PENDENTE** (aguardando `DATABASE_URL` no Codespaces/Supabase).

### 4.4 Seed do Catálogo e Persistência
- **Em Banco Real SQLite (`Subtestes 18, 19`):** **EXECUTADO E APROVADO** (CRUD de catálogo, pedidos, status, restart do processo e imutabilidade financeira).
- **No Adaptador `PostgresOrderStore` (`Subtestes 17, 21, 22` — Mock Stateful):** **EXECUTADO E APROVADO** (seed inicial, `pg_advisory_xact_lock`, rollback em falha, preservação de preço editado/produto inativado pelo admin após restart e 2º seed).
- **Em PostgreSQL Real (`npm run homolog:pg`):** **PENDENTE** de `DATABASE_URL` externa.

### 4.5 Situação da RLS e da Conexão Privilegiada do Backend
- **Importante (Transparência de Arquitetura):** Quando o backend Node.js conecta ao Supabase via `DATABASE_URL` usando a role padrão `postgres` (que possui `rolbypassrls = true`), **o PostgreSQL ignora as políticas RLS para essa conexão direta do backend**.
- Portanto, a proteção das rotas HTTP do servidor Node.js **NÃO depende da RLS**, mas sim das camadas implementadas e testadas em `server/src/index.mjs` e `argon4Engine.mjs`:
  1. Autenticação administrativa HMAC-SHA256 (`authenticateAdminRequest`, verificação de `exp`, revogação `jti`, RBAC por papel e rate limit anti-brute-force).
  2. Consulta pública de pedido (`GET /api/orders/:id`) protegida por `X-Order-Access-Token` + mascaramento de PII (`_sanitizeOrderForCustomerLookup`).
  3. Bloqueio explícito de headers `service_role` e caminhos `/rest/v1/*` no servidor HTTP.
- Já as políticas RLS das migrations `0006` e `0007` protegem o banco contra acessos diretos via PostgREST/Data API do Supabase (`anon` e `authenticated`). A execução dinâmica de `tests/postgres-integration-rls.mjs` permanece **PENDENTE** de instância PostgreSQL real.

---

## 5. Resultado Individual dos Testes e Identificação (Real vs Simulado)

| Teste / Comando | Natureza da Evidência | Status | Resultado Obtido |
|---|---|---|---|
| `node scripts/verify-migrations-order.mjs` | **Inspeção Estática / Sintática SQL** | **EXECUTADO** | `9/9` migrations íntegras (`ok: true`) |
| `npm test` — Subtestes 1 a 16, 18 a 20 | **REAL (SQLite 3.40.1 ACID em disco + Servidor HTTP Node.js)** | **EXECUTADO** | `19/19` suítes aprovadas (`0` falhas) |
| `npm test` — Subtestes 17, 21 e 22 | **REAL (Algoritmo UUID v5 + `/api/health`) + SIMULADO (Mocks `pg.Pool`)** | **EXECUTADO** | `3/3` suítes aprovadas (`22/22` total em `20.085 ms`) |
| `node scripts/run-browser-e2e-chromium.mjs` | **REAL (Navegador Chromium Headless `390x844` + SQLite + HTTP)** | **EXECUTADO** | `ok: true`, `#PZ-9041`, `confirmed`, `innerWidth: 390`, `scrollWidth: 390`, `js_errors: 0` |
| `node --test tests/postgres-integration-rls.mjs` | **REAL (PostgreSQL / Supabase Dinâmico)** | **NÃO EXECUTADO (SKIP)** | Sem `DATABASE_URL` no ambiente offline |
| `npm run homolog:pg` (`scripts/run-postgres-homologation.mjs`) | **REAL (PostgreSQL / Supabase — 15 Etapas)** | **NÃO EXECUTADO** | Sem `DATABASE_URL` e sem pacote `pg` no ambiente offline |

---

## 6. Pendências Externas

1. Abrir o projeto no **GitHub Codespaces** (com acesso à internet) e rodar `npm install` para baixar o pacote `pg` e gerar o `package-lock.json` oficial.
2. Conectar a `DATABASE_URL` de um projeto **Supabase de homologação/staging** (nunca produção).
3. Executar `npm run homolog:pg` e `npm run test:pg:rls` e coletar os logs reais do PostgreSQL.

---

## 7. Comandos Exatos para Continuar no GitHub Codespaces e Supabase

```bash
# 1. Extrair o ZIP da Missão 11 no GitHub Codespaces e entrar na pasta
unzip argon4-pizzaria-fullstack.zip
cd argon4-pizzaria-fullstack

# 2. Instalar a dependência oficial `pg` e gerar o package-lock.json real
npm install
npm ci

# 3. Configurar variáveis do banco Supabase de HOMOLOGAÇÃO (nunca produção!)
export DATABASE_DRIVER=postgres
export DATABASE_URL="postgresql://postgres:[SENHA_HOMOLOG]@db.[REF_PROJETO_HOMOLOG].supabase.co:5432/postgres"

# 4. Executar as 15 etapas de homologação PostgreSQL real (migrations 0001-0009, seed, restart, rollback, concorrência)
npm run homolog:pg

# 5. Executar validação dinâmica de RLS (anon, authenticated, service_role e auditoria de conexão)
npm run test:pg:rls

# 6. Executar regressão completa
npm test
```
