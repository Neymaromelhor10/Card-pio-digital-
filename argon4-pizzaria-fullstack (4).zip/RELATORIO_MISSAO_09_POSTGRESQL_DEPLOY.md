# ARGON 4 — MISSÃO 09: RELATÓRIO DE HOMOLOGAÇÃO POSTGRESQL/SUPABASE E PREPARAÇÃO PARA DEPLOY

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 09 — Homologação PostgreSQL/Supabase e Preparação para Deploy  
**Base Preservada:** Backup intacto da Missão 08 em `argon4-pizzaria-fullstack-backup-missao08.zip` (SHA-256: `34021fdde7aaa97c331bd22c709399c3a01adae7838c4513655d0253b4a20fe6`)  
**Data:** 2026-11-16  
**Status PostgreSQL:** **NÃO HOMOLOGADO AO VIVO NESTE AMBIENTE OFFLINE** (adaptador e migrations corrigidos, scripts prontos; validação real pendente de instância Supabase/PostgreSQL externa e `npm install pg`).

---

## 1. Resumo Executivo

A Missão 09 auditou integralmente a camada PostgreSQL (`postgresOrderStore.mjs`, `createOrderStore.mjs`, `argon4Engine.mjs`, `start.mjs`, `index.mjs`, `package.json`, `.env.example` e migrations `0001` a `0008`), corrigiu **duas incompatibilidades críticas** que impediriam a operação real no Supabase, preparou os artefatos de deploy para servidor Node.js persistente (`Dockerfile`, `render.yaml`), reforçou o comportamento *fail-closed* e a segurança HTTP (CORS restritivo + headers), e **resolveu e comprovou a divergência do viewport mobile (`390x844` reais no Chromium Headless, `scrollWidth: 390`, `0` erros JS)**.

---

## 2. Auditoria do Adaptador PostgreSQL e Correções Cirúrgicas

### Incompatibilidades Críticas Encontradas e Corrigidas
1. **Incompatibilidade `UUID` vs Slugs do Domínio (`est-forno-nobre-01`, `cat-*`, `prod-*`, `flav-*`, `crust-*`, `cup-*`):**
   - **Problema:** A Migration `0001` define `id UUID` nas tabelas de catálogo (`establishments`, `categories`, `pizza_sizes`, `products`, `pizza_flavors`, `product_addons`, `coupons`), mas o domínio e o frontend utilizam IDs legíveis em texto (`est-forno-nobre-01`, `prod-pepperoni-burrata`). Em PostgreSQL real, inserir esses textos em colunas `UUID` causaria falha imediata (`invalid input syntax for type uuid`).
   - **Correção:** Criada a migration incremental não-destrutiva **`0009_argon4_postgres_external_ids_and_homologation.sql`** adicionando `external_id TEXT` com índices únicos parciais, e implementado `toPgUuid(rawId)` determinístico (UUID v5 via SHA-256) em `server/src/db/postgresOrderStore.mjs`. Na leitura (`loadAll()`), o adaptador retorna `COALESCE(external_id, id::text) AS id`, mantendo 100% de compatibilidade com o SQLite e o frontend.
2. **Ausência de Seed e Carregamento de Catálogo em `PostgresOrderStore`:**
   - **Problema:** `PostgresOrderStore.loadAll()` não carregava `establishments`, `store_settings`, `categories`, `pizza_sizes`, `products`, `pizza_flavors`, `product_addons` nem `coupons`, e não implementava `seedCatalogIfEmpty()`. Além disso, `argon4Engine.mjs._syncFromDatabase()` não disparava o seed quando o banco PostgreSQL estava vazio.
   - **Correção:** Implementado `seedCatalogIfEmpty(payload)` transacional em `PostgresOrderStore`, atualizado `loadAll()` para hidratar todas as tabelas de catálogo + `catalog_initialized`, e atualizado `argon4Engine.mjs._syncFromDatabase()` para semear automaticamente o catálogo na primeira execução contra um PostgreSQL vazio.

---

## 3. Relação de Arquivos Modificados e Criados

| Arquivo | Tipo | Finalidade na Missão 09 |
|---|---|---|
| `supabase/migrations/0009_argon4_postgres_external_ids_and_homologation.sql` | Criado | Adiciona `external_id TEXT` e índices únicos nas tabelas de catálogo/cupons sem alterar migrations `0001`–`0008`. |
| `server/src/db/postgresOrderStore.mjs` | Modificado | Adiciona `toPgUuid()`, `seedCatalogIfEmpty()`, carregamento completo de catálogo em `loadAll()` e conversão UUID em queries/upserts. |
| `server/src/domain/argon4Engine.mjs` | Modificado | Atualiza `_syncFromDatabase()` para semear catálogo vazio via `seedCatalogIfEmpty()` no modo assíncrono (`postgres`). |
| `server/src/start.mjs` | Modificado | Bloqueia (`fail-closed`) `DATABASE_DRIVER=sqlite` em ambiente serverless (`VERCEL`, `AWS_LAMBDA_FUNCTION_NAME`, `NETLIFY`) ou `NODE_ENV=production` sem `ALLOW_SQLITE_IN_PRODUCTION=true`. |
| `server/src/index.mjs` | Modificado | Adiciona `Referrer-Policy`, `Permissions-Policy` e CORS restritivo configurável por `CORS_ALLOWED_ORIGINS` (preflight `OPTIONS`, nunca `*`). |
| `.env.example` | Modificado | Documenta `CORS_ALLOWED_ORIGINS` e `ALLOW_SQLITE_IN_PRODUCTION` sem segredos reais. |
| `Dockerfile` | Criado | Container Node 20 Alpine para hospedagem persistente com `npm ci --omit=dev` e `HEALTHCHECK` em `/api/health`. |
| `render.yaml` | Criado | Blueprint declarativo para Render Web Service Node.js persistente conectado ao Supabase PostgreSQL (`sync: false` para segredos). |
| `public/index.html` (+ cópia `argon4-pizzaria-cardapio.html`) | Modificado | Adiciona fallback CSS nativo (`html, body { max-width: 100%; overflow-x: hidden; }`, `.hidden { display: none !important; }`, `img, video { max-width: 100%; height: auto; }`) garantindo `390px` reais sem zoom-out mesmo offline. |
| `scripts/run-browser-e2e-chromium.mjs` | Modificado | Configura `screenWidth: 390, screenHeight: 844`, `setTouchEmulationEnabled`, captura de falhas de recursos locais e valida estritamente `innerWidth === 390` e `scrollWidth <= 390`. |
| `scripts/run-postgres-homologation.mjs` | Modificado | Inclui verificação de hidratação de catálogo (`loadAll()`) além das 4 ondas de concorrência, rollback e integridade. |

---

## 4. Migrations Verificadas (`0001` a `0009`)

Executado `node scripts/verify-migrations-order.mjs`:
- **Resultado:** `ok: true`, `count: 9` migrations sequenciais (`0001` a `0009`), todas envolvidas em blocos transacionais (`BEGIN`/`COMMIT`) e com `destructive_drop: false`.

---

## 5. Correção da Evidência Mobile Real (`390x844`)

- **Causa da divergência na Missão 08 (`innerWidth: 776`):** Quando a CDN externa do Tailwind estava bloqueada no ambiente offline, o `<style>` nativo não possuía `.hidden { display: none !important; }` nem `max-width: 100%` no `<html>` e mídias; elementos sem estilo expandiam além de `390px`, acionando o zoom-out automático do modo `mobile: true` no Chromium para `776px`.
- **Evidência real obtida após correção (`node scripts/run-browser-e2e-chromium.mjs`):**
  - `window.innerWidth`: **`390`**
  - `window.innerHeight`: **`844`**
  - `document.documentElement.scrollWidth`: **`390`** (overflow horizontal = `0px`)
  - `window.devicePixelRatio`: **`2`**
  - `isMobile`: **`true`** | `hasTouch`: **`true`** (`maxTouchPoints: 5`)
  - `js_errors`: **`0`** | `local_resource_failures`: **`0`**
  - Fluxo completo validado no navegador: carregamento via `GET /api/catalog`, pizza meio a meio + borda, checkout sem CEP, pedido `#PZ-9041` persistido no SQLite, atualização no Admin para `confirmed` e consulta posterior do cliente.

---

## 6. Resultado dos Testes de Regressão (Separação por Tipo de Evidência)

| Execução | Tipo de Evidência | Resultado |
|---|---|---|
| `node scripts/verify-migrations-order.mjs` | Validação estrutural SQL | **APROVADO** (`9/9` migrations válidas) |
| `npm test` (`tests/argon4-suite.mjs`) | **Banco Real SQLite (WAL)** + API HTTP + Mock `pg.Pool` (Subteste 17) | **APROVADO** (`20/20` suítes, `0` falhas, `20.608 ms`) |
| `node scripts/run-browser-e2e-chromium.mjs` | **Navegador Real (Chromium Headless `390x844`)** + SQLite Real | **APROVADO** (`ok: true`, `#PZ-9041`, `confirmed`) |
| `node --test tests/postgres-integration-rls.mjs` | PostgreSQL / Supabase Dinâmico (RLS) | **SKIPPED** (sem `DATABASE_URL` e sem daemon PostgreSQL no container offline) |

---

## 7. Configuração de Hospedagem Recomendada (Node.js Persistente vs Serverless)

- **Arquitetura Recomendada:** Servidor Node.js persistente (**Render Web Service** via `render.yaml`, **Railway**, **Fly.io** ou **VPS com Docker** via `Dockerfile`) executando `npm start`, conectado a um banco **Supabase PostgreSQL** (`DATABASE_DRIVER=postgres` + `DATABASE_URL` do Session/Transaction Pooler).
- **Por que NÃO publicar em Vercel Serverless puro:**
  1. `server/src/index.mjs` sobe um servidor HTTP contínuo (`http.createServer`) com rate limiter e estado de sessões em memória.
  2. `SQLite` em disco local não persiste em funções serverless efêmeras (o `start.mjs` agora aborta explicitamente se detectar `VERCEL`/`AWS_LAMBDA_FUNCTION_NAME` com `sqlite`).
- **Comportamento Fail-Closed em Produção (`NODE_ENV=production`):**
  - Exige `ADMIN_API_TOKEN` e `SESSION_SECRET` com mínimo de `32` caracteres e bloqueia segredos de exemplo.
  - Exige `DATABASE_DRIVER=postgres` com `DATABASE_URL` válida (salvo override explícito `ALLOW_SQLITE_IN_PRODUCTION=true` em servidor com volume persistente).

---

## 8. Scripts de Homologação e Comandos para Execução em Staging (PostgreSQL/Supabase Real)

No ambiente com acesso à internet e ao projeto Supabase do usuário:
```bash
# 1. Instalar dependência oficial do PostgreSQL
npm install pg

# 2. Definir variáveis de homologação (nunca usar banco de produção para testes destrutivos)
export DATABASE_DRIVER=postgres
export DATABASE_URL="postgresql://postgres:[SUA_SENHA]@db.[SEU_PROJETO].supabase.co:5432/postgres"

# 3. Aplicar migrations 0001..0009 + testar rollback, catálogo e concorrência (10/25/50/100)
npm run homolog:pg

# 4. Executar testes dinâmicos de RLS (anon, authenticated, service_role)
npm run test:pg:rls

# 5. Subir servidor em modo produção apontando para o Supabase
export NODE_ENV=production
export ADMIN_API_TOKEN="$(openssl rand -hex 32)"
export SESSION_SECRET="$(openssl rand -hex 32)"
npm start
```

---

## 9. Pendências Externas (Dependem de Contas/Credenciais do Usuário)

1. Criar ou selecionar o projeto no **Supabase** e obter a `DATABASE_URL` (Session/Transaction Pooler) e credenciais de API.
2. Executar `npm install pg`, `npm run homolog:pg` e `npm run test:pg:rls` contra o banco de **homologação** no Supabase.
3. Configurar as variáveis de ambiente (`DATABASE_URL`, `ADMIN_API_TOKEN`, `SESSION_SECRET`, `CORS_ALLOWED_ORIGINS`) no provedor Node.js escolhido (Render/Railway/Docker).
4. (Missões futuras) Conectar credenciais reais da Meta WhatsApp Cloud API e gateway de pagamento, quando autorizado.
