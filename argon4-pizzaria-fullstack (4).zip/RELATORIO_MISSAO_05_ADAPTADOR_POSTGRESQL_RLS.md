# RELATÓRIO TÉCNICO — ARGON 4: MISSÃO 05 — ADAPTADOR POSTGRESQL/SUPABASE, PERSISTÊNCIA REAL E VALIDAÇÃO DINÂMICA DE RLS

## 1. Resumo Executivo e Transparência de Status (Critérios da Seção 14)
Esta missão implementou a separação estrutural da camada de persistência, o adaptador completo **PostgreSQL/Supabase (`server/src/db/postgresOrderStore.mjs`)**, a fábrica explícita de driver **`server/src/db/createOrderStore.mjs`** (`DATABASE_DRIVER=sqlite` vs `DATABASE_DRIVER=postgres`, com **fail-closed** sem fallback silencioso), a migration incremental **`0007_argon4_postgres_adapter_and_rls_compat.sql`** e os scripts executáveis de homologação e testes dinâmicos de RLS (`scripts/run-postgres-homologation.mjs` e `tests/postgres-integration-rls.mjs`).

> **DECLARAÇÃO TRANSPARENTE DE AMBIENTE E LIMITAÇÃO**:
> Neste container de build offline não há daemon PostgreSQL (`postgres`/`psql`), nem Supabase CLI (`supabase`), nem pacote `pg` instalado no `node_modules` (e o acesso de saída à internet está bloqueado). Portanto, **não declaramos o PostgreSQL nem as políticas RLS validados contra uma instância viva de PostgreSQL neste ambiente**. Os requisitos que dependem de conexão real com o banco PostgreSQL estão explicitamente classificados como **PENDENTES** na matriz abaixo, acompanhados dos scripts executáveis prontos para rodar no ambiente de homologação/staging.

### Matriz Objetiva dos Critérios de Aprovação (Seção 14)

| # | Critério de Aprovação | Status Atual | Evidência / Observação |
| :--- | :--- | :--- | :--- |
| **1** | Adaptador PostgreSQL implementado (`PostgresOrderStore`) | **IMPLEMENTADO E VALIDADO EM CONTRATO** | `server/src/db/postgresOrderStore.mjs` com `pg.Pool`, SQL parametrizado `$1..$N`, `pg_advisory_xact_lock`, `BEGIN`/`COMMIT`/`ROLLBACK` |
| **2** | Interface comum de persistência com fail-closed | **IMPLEMENTADO E TESTADO** | `server/src/db/createOrderStore.mjs` + Subteste 17 (`POSTGRES_CONFIG_MISSING` sem fallback silencioso) |
| **3** | Servidor inicia usando PostgreSQL real | **PENDENTE (Staging)** | Código pronto em `server/src/start.mjs` (`healthCheck()` + `init()` + shutdown gracioso); requer `DATABASE_URL` real |
| **4** | Pedidos persistidos no PostgreSQL real | **PENDENTE (Staging)** | Coberto por contrato/stub no Subteste 17; execução real via `npm run homolog:pg` |
| **5** | Transações atômicas (rollback em item, pagamento, histórico, outbox) | **VALIDADO EM CONTRATO + SQLITE REAL; PENDENTE EM PG VIVO** | Subteste 17 comprova `ROLLBACK` e `release()` em todos os 4 pontos de falha |
| **6** | Idempotência sob concorrência no PostgreSQL | **PENDENTE (Staging)** | Lógica SQL + `pg_advisory_xact_lock` + `UNIQUE(establishment_id, idempotency_key)` implementadas |
| **7** | Migrations `0001` a `0007` verificadas em ordem | **VERIFICADO ESTRUTURALMENTE (`7/7`); PENDENTE EXECUÇÃO EM PG VIVO** | `scripts/verify-migrations-order.mjs` aprovado (`7/7`, `BEGIN`/`COMMIT`, zero `DROP` destrutivo) |
| **8** | Políticas RLS testadas dinamicamente com `anon`, `authenticated`, `service_role` | **PENDENTE (Staging)** | Suíte pronta em `tests/postgres-integration-rls.mjs` (não executada por ausência de PG no container) |
| **9** | Isolamento entre 3 estabelecimentos no PostgreSQL real | **VALIDADO EM SQLITE + ENGINE; PENDENTE EM PG VIVO** | Subteste 16 aprovado; seed multi-estabelecimento incluído em `scripts/run-postgres-homologation.mjs` |
| **10** | Pool de conexões sem vazamentos | **VALIDADO EM CONTRATO (`acquiredCount === releasedCount`)** | `finally { client.release(); }` + `pool.end()` no shutdown |
| **11** | Regressão completa (Missões 01–05 + 02 + 03 + 04) | **APROVADO (`17/17` SUÍTES PASS)** | `node --test tests/argon4-suite.mjs` (`17/17 pass`, `0 fail`) |

---

## 2. Auditoria da Arquitetura de Persistência e Separação de Camadas
- **Camada de Domínio (`server/src/domain/argon4Engine.mjs`)**: Concentra exclusivamente regras de negócio (cálculo server-side de pizzas/meio-a-meio/adicionais, taxas por bairro, cupons, geração de hashes canônicos de idempotência, isolamento multi-estabelecimento, formatação WhatsApp e tracking). Não contém comandos SQL específicos de SQLite nem PostgreSQL.
- **Camada de Persistência (`server/src/db/`)**:
  - `createOrderStore.mjs`: Fábrica comum que resolve `DATABASE_DRIVER` (`sqlite` ou `postgres`) sem fallback silencioso.
  - `sqliteOrderStore.mjs`: Driver local ACID em SQLite 3.40.1 (desenvolvimento e testes automatizados offline).
  - `postgresOrderStore.mjs`: Driver PostgreSQL/Supabase utilizando `pg.Pool` e transações explícitas.
- **Camada HTTP (`server/src/index.mjs`)**: Autenticação RBAC, HMAC de sessões/webhooks, rate limiting, `X-Correlation-Id`/`X-Request-Id` e mapeamento seguro de erros.
- **Infraestrutura (`server/src/start.mjs`)**: Fail-closed na inicialização de segredos e conexão ao banco, e encerramento gracioso (`SIGINT`/`SIGTERM`) fechando servidor HTTP e pool de conexões.

---

## 3. Configuração do Pool PostgreSQL / Supabase (Compatibilidade PgBouncer)
Parâmetros explícitos configurados em `buildPostgresPoolConfig()` (`server/src/db/postgresOrderStore.mjs`) e documentados em `.env.example`:
- `PG_POOL_MAX=10`: Limite conservador compatível com planos Supabase Free/Pro e PgBouncer em modo Transaction/Session Pooling (evita esgotamento de `max_connections`).
- `PG_CONNECTION_TIMEOUT_MS=5000`: Falha rápida em 5s se o banco estiver inacessível.
- `PG_IDLE_TIMEOUT_MS=30000`: Libera conexões ociosas após 30s.
- `PG_STATEMENT_TIMEOUT_MS=10000` e `PG_QUERY_TIMEOUT_MS=10000`: Protege contra queries travadas ou locks prolongados.
- `PG_SSL_REJECT_UNAUTHORIZED=true`: SSL estrito habilitado automaticamente para hosts remotos (Supabase Cloud) e desabilitado apenas para `localhost`/`127.0.0.1`.

---

## 4. Auditoria e Compatibilidade das Migrations (`0001` a `0007`)
- Todas as migrations históricas `0001` a `0006` foram preservadas intactas byte-a-byte.
- Adicionada a migration incremental **`supabase/migrations/0007_argon4_postgres_adapter_and_rls_compat.sql`**:
  - Adiciona `cash_change_amount_cents`, `pix_details`, `purchase_event_id`, `correlation_id` e `request_id` em `public.orders`.
  - Adiciona `cart_item_id`, `is_pizza` e `selected_flavor_ids` em `public.order_items`.
  - Cria índices `idx_establishments_slug` e `idx_orders_correlation_id`.
  - Configura `ALTER VIEW public.v_public_storefront_settings SET (security_invoker = true)` para compatibilidade com PostgreSQL 15+ e PostgREST.

---

## 5. Estratégia de Backup, Retenção e Recuperação (Seção 12)
Para operação comercial no Supabase/PostgreSQL:
1. **Backups Diários & Point-in-Time Recovery (PITR)**: Habilitar backups automáticos diários do Supabase (retenção mínima de 7 a 30 dias) e PITR com WAL archiving para recuperação granular por segundo sem perda de pedidos confirmados.
2. **Verificação de Integridade**: Executar periodicamente `pg_dump` lógico de verificação em banco de restore isolado (`RESTORE_TEST_DATABASE_URL`) validando contagens de `orders`, `order_items` e `payments` sem chaves órfãs.
3. **Proteção de Dados Pessoais (LGPD)**: Backups e snapshots devem permanecer criptografados em repouso (AES-256), nunca ser restaurados em ambientes públicos sem anonimização de `customers.phone` e `customer_addresses`, e nunca conter segredos em texto plano.

---

## 6. Instruções de Execução (Local e Staging PostgreSQL)
```bash
# 1. Verificar ordem e integridade das migrations 0001–0007:
npm run verify:migrations

# 2. Executar suíte completa de testes locais e regressão (SQLite ACID + Contrato PG):
npm test

# 3. Em ambiente Staging/Homologação com PostgreSQL/Supabase ativo:
npm install pg
export DATABASE_DRIVER=postgres
export DATABASE_URL="postgresql://usuario:senha@host:5432/postgres"
npm run homolog:pg
npm run test:pg:rls
```
