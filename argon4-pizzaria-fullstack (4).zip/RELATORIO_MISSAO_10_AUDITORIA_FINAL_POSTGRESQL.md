# ARGON 4 — MISSÃO 10: RELATÓRIO DE AUDITORIA FINAL DE PREPARAÇÃO POSTGRESQL/SUPABASE, RLS E SEGURANÇA DE PRODUÇÃO

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 10 — Auditoria Final de Preparação PostgreSQL/Supabase  
**Base Preservada:** Backup intacto da Missão 09 em `argon4-pizzaria-fullstack-backup-missao09.zip` (SHA-256: `0cd844c1981aa066627bc08179c0acc41ee5839cbc56aaaecfde01505af29d12`)  
**Data:** 2026-11-17  
**Classificação Final:** **APROVADA PARA HOMOLOGAÇÃO** *(NÃO declarada validada em produção ao vivo por ausência de servidor PostgreSQL/Supabase neste container offline).*

---

## 1. Resumo Executivo

A Missão 10 executou uma auditoria forense independente sobre a Migration `0009`, conversão UUID v5 (`toPgUuid`), seed transacional (`seedCatalogIfEmpty`), carregamento do catálogo (`loadAll`), políticas RLS (`0006`), segredos/configurações de produção, pool/TLS para Supabase e artefatos de deploy (`Dockerfile`, `render.yaml`, `.gitignore`).

Foram identificadas e corrigidas **5 falhas reais** que comprometeriam o primeiro deploy ou a homologação concorrente no Supabase. Todos os **21/21 testes automatizados**, **9/9 migrations** e o **teste real em Chromium Headless (`390x844`)** passaram após as correções.

---

## 2. Falhas Identificadas e Correções Realizadas

| ID | Arquivo | Falha Identificada | Correção Cirúrgica Aplicada |
|---|---|---|---|
| **M10-F01** | `.gitignore` (criado) | Ausência de `.gitignore` na raiz do projeto, expondo risco de versionar `.env`, `node_modules/` ou arquivos `.sqlite` locais no GitHub. | Criado `.gitignore` ignorando `.env`, `.env.*` (preservando `!.env.example`), `node_modules/`, `data/*.sqlite*`, `data/chrome-profile-*` e logs. |
| **M10-F02** | `server/src/db/postgresOrderStore.mjs` | `seedCatalogIfEmpty()` verificava `COUNT(*)` sem lock transacional; duas inicializações simultâneas em banco vazio poderiam colidir em `UNIQUE(establishment_id, slug)` ou `store_settings`. | Adicionado `SELECT pg_advisory_xact_lock(hashtext('argon4:seed_catalog_v1'))` logo após `BEGIN`, serializando seeds concorrentes de forma atômica. |
| **M10-F03** | `server/src/db/postgresOrderStore.mjs` | Os métodos `upsertCategory`, `upsertProduct`, `upsertPizzaSize`, `upsertPizzaFlavor`, `upsertProductAddon` e `upsertCoupon` não gravavam/atualizavam `external_id`; além disso, `loadAll()` usava subconsultas sem alias qualificado e `_hydrateOrderRow` não priorizava `app_est_id`/`app_product_id`. | Atualizados todos os `upsert*` para gravar `external_id` e preservá-lo no `ON CONFLICT DO UPDATE`, qualificados os aliases (`c.`, `ps.`, `p.`, `pf.`, `pa.`, `cp.`) em `loadAll()` e preservados `app_est_id`/`app_product_id` na hidratação. |
| **M10-F04** | `Dockerfile` e `render.yaml` | Ambos executavam `npm ci --omit=dev`, mas o repositório não possui `package-lock.json` (gerável apenas com acesso ao registry npm), o que faria o build falhar imediatamente no Docker/Render. | Atualizados `Dockerfile` e `render.yaml` para usar `if [ -f package-lock.json ]; then npm ci --omit=dev; else npm install --omit=dev; fi`. |
| **M10-F05** | `server/src/index.mjs` | `Dockerfile` e `render.yaml` apontavam o healthcheck para `/api/health`, mas a rota `GET /api/health` não existia em `server/src/index.mjs` (retornaria 404 e derrubaria o deploy). | Implementada rota `GET /api/health` retornando `200 OK` com `{ ok: true, status: "healthy", driver, timestamp }`, sem expor `DATABASE_URL`, caminhos locais ou segredos. |

---

## 3. Situação dos Componentes Auditados

### 3.1 Migration 0009 (`0009_argon4_postgres_external_ids_and_homologation.sql`)
- **Status:** **Aprovada estruturalmente** (`BEGIN`/`COMMIT`, `ADD COLUMN IF NOT EXISTS external_id TEXT`, `CREATE UNIQUE INDEX IF NOT EXISTS ... WHERE external_id IS NOT NULL`, zero `DROP` destrutivo).
- **Compatibilidade:** 100% compatível com PostgreSQL 15+ e Supabase, preservando PKs/FKs `UUID` da Migration `0001` e sem modificar migrations históricas `0001`–`0008`.

### 3.2 Conversão UUID (`toPgUuid(rawId)`)
- **Status:** **Determinística, reprodutível e sem colisões** (validada no Subteste 21).
- Preserva UUIDs já válidos (`^[0-9a-f]{8}-...$`), trata `null`/`''` retornando `null`, e converte IDs textuais (`est-forno-nobre-01`, `cat-*`, `prod-*`, `flav-*`, `crust-*`, `cup-*`) em UUID v5 determinístico via SHA-256 (`argon4:uuid:<id>`).

### 3.3 Seed do Catálogo (`seedCatalogIfEmpty`) e Carregamento (`loadAll`)
- **Status:** **Transacional, serializado e idempotente.**
- Na 1ª inicialização em banco vazio, semeia estabelecimento, configurações, categorias, tamanhos, produtos, sabores, adicionais e cupons com `external_id`.
- Em inicializações subsequentes (`COUNT(*) > 0`), retorna `{ ok: true, seeded: false }` sem sobrescrever alterações do administrador.
- Em falha intermediária, executa `ROLLBACK` completo e libera a conexão (`client.release()`).

### 3.4 RLS e Supabase (`0006` e rotas HTTP)
- **Status:** **Estruturalmente configurada nas migrations; validação dinâmica PENDENTE de PostgreSQL real.**
- `anon` tem acesso revogado às tabelas sensíveis (`orders`, `customers`, `admin_users`, `store_settings`, `payments`) e lê apenas a view higienizada `v_public_storefront_settings` (`security_invoker = true`).
- O backend Node.js usa `DATABASE_URL` privilegiada no servidor e aplica validação própria de RBAC, HMAC-SHA256 (`exp`/`jti`), `X-Order-Access-Token` com mascaramento de PII (`M08-F01`), rate limiting e bloqueio explícito de headers `service_role` vindos de clientes.
- O frontend (`public/index.html`) não recebe `DATABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `ADMIN_API_TOKEN` nem `SESSION_SECRET`.

### 3.5 Conexão e Pool Supabase (`buildPostgresPoolConfig`)
- Suporta **Supabase Session Pooler (porta 5432)** e **Transaction Pooler (porta 6543)** — todas as queries do `PostgresOrderStore` usam parâmetros posicionais (`$1, $2, ...`) sem `PREPARE` nomeado explícito, mantendo compatibilidade com PgBouncer em modo Transaction.
- TLS/SSL ativo com `rejectUnauthorized: true` por padrão fora de `localhost`/`127.0.0.1` (sem desabilitar verificação de certificado).
- Timeouts configuráveis (`connectionTimeoutMillis: 5000`, `idleTimeoutMillis: 30000`, `statement_timeout: 10000`, `query_timeout: 10000`) e `fail-closed` se `DATABASE_URL` ou pacote `pg` estiverem ausentes.

---

## 4. Resultado Individual dos Testes (Separado por Tipo de Evidência)

| Suite / Script | Tipo de Evidência | Resultado |
|---|---|---|
| `node scripts/verify-migrations-order.mjs` | Inspeção Estrutural SQL (`0001`–`0009`) | **APROVADO** (`9/9` válidas, transacionais, sem `DROP` destrutivo) |
| Subtestes 1–16, 18–20 (`npm test`) | **Banco Real SQLite (WAL)** + Servidor HTTP Real | **APROVADO** (`19/19` suítes SQLite reais, 0 falhas) |
| Subteste 17 (`npm test`) | **Mock `pg.Pool`** + Contrato Fail-Closed | **APROVADO** (interface comum, parametrização `$1..$N`, rollback) |
| Subteste 21 (`npm test`) | **UUID v5 + Mock `pg.Pool` (Seed/Rollback) + Inspeção Estática + `/api/health` SQLite Real** | **APROVADO** (`129.22 ms`, `21/21` total em `19.900 ms`) |
| `node scripts/run-browser-e2e-chromium.mjs` | **Navegador Real (Chromium Headless `390x844`)** + SQLite Real | **APROVADO** (`innerWidth: 390`, `innerHeight: 844`, `scrollWidth: 390`, `js_errors: 0`, `#PZ-9041`, `confirmed`) |
| `node --test tests/postgres-integration-rls.mjs` | PostgreSQL / Supabase Real (RLS Dinâmico) | **SKIPPED** (sem `DATABASE_URL` e sem daemon PostgreSQL no ambiente offline) |

---

## 5. Pendências que Exigem Ambiente Externo (Pré-Go-Live)

1. Criar projeto no **Supabase** e gerar a `DATABASE_URL` de homologação.
2. Instalar o driver oficial (`npm install pg`) em ambiente com acesso ao registry npm (e commitar o `package-lock.json` gerado).
3. Executar os comandos de homologação real abaixo contra o banco de **homologação** (nunca contra produção).
4. Configurar as variáveis de ambiente (`DATABASE_DRIVER=postgres`, `DATABASE_URL`, `ADMIN_API_TOKEN`, `SESSION_SECRET`, `CORS_ALLOWED_ORIGINS`) no provedor Node.js persistente (Render/Railway/Docker).

---

## 6. Comandos Exatos para Homologação Real no Supabase

```bash
# 1. Instalar dependência oficial PostgreSQL (gera package-lock.json para o deploy)
npm install pg

# 2. Definir ambiente de homologação (substituir pelos dados do projeto Supabase de staging)
export DATABASE_DRIVER=postgres
export DATABASE_URL="postgresql://postgres:[SUA_SENHA]@db.[SEU_PROJETO].supabase.co:5432/postgres"

# 3. Aplicar migrations 0001..0009 + validar seed, catálogo, rollback e concorrência (10/25/50/100)
npm run homolog:pg

# 4. Validar dinamicamente as políticas RLS (anon, authenticated, service_role)
npm run test:pg:rls

# 5. Subir servidor em modo produção conectado ao Supabase
export NODE_ENV=production
export ADMIN_API_TOKEN="$(openssl rand -hex 32)"
export SESSION_SECRET="$(openssl rand -hex 32)"
export CORS_ALLOWED_ORIGINS="https://seudominio.com.br"
npm start
```
