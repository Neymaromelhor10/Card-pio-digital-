# ARGON 4 — MISSÃO 14: RELATÓRIO DE AUDITORIA INDEPENDENTE DAS CORREÇÕES DA MISSÃO 13 E INTEGRIDADE TRANSACIONAL

**Projeto:** Cardápio Digital — *Forno Nobre Pizzaria Napoletana & Grill* (`est-forno-nobre-01`)  
**Missão:** 14 — Auditoria Independente das Correções da Missão 13 e Integridade Transacional  
**Backup Original Preservado:** `argon4-pizzaria-fullstack-backup-missao13.zip` (SHA-256: `09440cf1d1db622940da606ad12a3b426140b6f7ae22be7ea78d42c3d6d546e4`)  
**Data:** 2026-11-17  
**Status da Missão 14:** **APROVADA LOCALMENTE** *(Todas as correções locais comprovadas foram implementadas, documentadas e testadas em **25/25 suítes** + Chromium `390x844`; GitHub, Codespaces, Supabase e deploy permanecem adiados conforme regra).*

---

## 1. Resumo Executivo

A Missão 14 auditou de forma independente as correções da Missão 13 (`M14-01` Contador de Cupons, `M14-02` Identificadores Externos de Estabelecimentos, `M14-03` Identificadores Externos de Produtos e `M14-04` Integridade das Consultas e Transações), além da integridade financeira e autorização administrativa.

A auditoria identificou e corrigiu **4 falhas residuais reais** na sincronização e concorrência de cupons e nas cláusulas `WHERE` de escrita por `external_id`. Foi criado o **Subteste 25** cobrindo todos os **12 cenários obrigatórios** da Seção 5, resultando em **25/25 suítes aprovadas (`0` falhas)** e **fluxo mobile `390x844` validado no Chromium**.

---

## 2. Lista de Problemas Encontrados, Gravidade e Correções Implementadas

| ID | Arquivo e Função Afetados | Gravidade | Causa e Impacto | Correção Mínima Implementada | Teste de Regressão |
|---|---|---|---|---|---|
| **M14-F01** | `server/src/domain/argon4Engine.mjs` (`_applyLoadedDatabaseState`) e `server/src/db/sqliteOrderStore.mjs` (`create_order_tx`) | **Alta** | No SQLite, `create_order_tx` incrementava apenas `coupons_usage` sem incrementar `coupons.used_count`. Ao reiniciar o servidor, `_applyLoadedDatabaseState` recalculava `c.used_count = baseUsed + (data.coupons_usage[c.id] || 0)` com `baseUsed` fixo (`18/42/67/5`), sobrescrevendo o `used_count` inicial de qualquer cupom criado/editado pelo administrador (ex: um cupom criado com `used_count: 4` e usado 1 vez voltaria para `5 + 1 = 6` após restart!). | `sqliteOrderStore.mjs` passa a incrementar atomicamente `UPDATE coupons SET used_count = used_count + 1 WHERE id = ?` dentro da transação, e `_applyLoadedDatabaseState` usa diretamente `c.used_count` da tabela `coupons` quando `catalog_initialized === true`. | `Subteste 25` (itens 1, 3, 4 e 5) |
| **M14-F02** | `server/src/db/postgresOrderStore.mjs` (`createOrderTransaction`) e `server/src/db/sqliteOrderStore.mjs` (`create_order_tx`) | **Alta** | O `UPDATE public.coupons SET used_count = used_count + 1 WHERE id = $1` não validava `AND (usage_limit IS NULL OR used_count < usage_limit)` nem checava `rowCount === 0` dentro da transação SQL. Sob concorrência entre múltiplos clientes ou conexões, duas compras simultâneas poderiam consumir a última vaga do cupom. | Atualizado o `UPDATE` em ambos os adaptadores para checar atomicamente `usage_limit IS NULL OR used_count < usage_limit` e abortar com `ROLLBACK` + `COUPON_USAGE_LIMIT_REACHED` se o limite tiver sido atingido. | `Subteste 25` (itens 3 e 8) |
| **M14-F03** | `server/src/domain/argon4Engine.mjs` (`saveCoupon`) | **Média** | `saveCoupon(payload)` definia `used_count: Number(payload?.used_count || 0)`, zerando o contador acumulado de um cupom existente sempre que o administrador atualizava apenas a descrição ou validade sem reenviar `used_count`. | `saveCoupon` agora busca `existing = this.state.coupons.find(c => c.id === id)` e preserva `existing.used_count` (e demais campos) quando omitidos no payload. | `Subteste 25` (item 1) |
| **M14-F04** | `server/src/db/postgresOrderStore.mjs` (`reorderCategories`, `deleteCategorySafe`, `deleteProductSafe`) | **Média** | As cláusulas `UPDATE`/`DELETE` filtravam apenas por `WHERE id::text = $1` com `toPgUuid(id)`, sem `OR external_id = $2`. Caso um registro fosse inserido no PostgreSQL com UUID aleatório e `external_id` textual, a operação não o encontraria. | Adicionado `OR external_id = $2` (ou `$3` no reorder) em todas as cláusulas de atualização/exclusão lógica de categorias e produtos. | `Subtestes 17, 22, 24, 25` |

---

## 3. Verificação dos Pontos M14-01 a M14-04

- **M14-01 (Contador de cupons):** Sincronizado de forma idêntica entre SQLite e PostgreSQL na tabela `coupons`; objetos vazios `coupons_usage: {}` não sobrescrevem `used_count`; falha no meio da transação executa rollback integral sem consumir cupom; duas compras simultâneas disputando a última vaga aprovam exatamente 1 e rejeitam a 2ª com `COUPON_USAGE_LIMIT_REACHED`; retries idempotentes e reinicializações do servidor mantêm `used_count` exato sem duplicar.
- **M14-02 (`establishment_id` / `app_est_id` / `external_id`):** Todas as consultas em `public.orders` (`loadAll`, `getOrderByIdempotencyKey`, `getOrderByIdOrCode`, `createOrderTransaction`) projetam `app_est_id` via `COALESCE((SELECT e.external_id ...), o.establishment_id::text)` e retornam `'est-forno-nobre-01'` consistentemente para listagem administrativa, detalhes, histórico e recuperação por código.
- **M14-03 (`product_id` / `app_product_id` / `external_id`):** Todas as leituras de `public.order_items` projetam `app_product_id` via `COALESCE((SELECT p.external_id ...), oi.product_id::text)`. Mesmo após reajuste de preço (`9990`) e exclusão lógica (`soft_deleted_history_preserved`), os itens e valores históricos do pedido permanecem imutáveis.
- **M14-04 (Integridade das consultas):** Subconsultas e aliases qualificados verificados em todos os caminhos de leitura e escrita, 100% compatíveis com PostgreSQL 15+.

---

## 4. Arquivos Modificados na Missão 14

| Arquivo | Modificação |
|---|---|
| `server/src/db/sqliteOrderStore.mjs` | Guarda transacional de `usage_limit` e incremento direto de `coupons.used_count` em `create_order_tx`. |
| `server/src/db/postgresOrderStore.mjs` | Incremento atômico de cupom com `AND (usage_limit IS NULL OR used_count < usage_limit)` + `rowCount === 0 -> COUPON_USAGE_LIMIT_REACHED` (rollback) e cláusulas `OR external_id` em categorias/produtos. |
| `server/src/domain/argon4Engine.mjs` | Preservação de `c.used_count` da tabela `coupons` quando `catalog_initialized === true` e preservação de `existing.used_count` em edições parciais no `saveCoupon()`. |
| `tests/argon4-suite.mjs` | Adicionado **Subteste 25** validando os 12 cenários obrigatórios da Missão 14. |

---

## 5. Testes Executados e Separação Explícita (Real vs Mock vs Estático)

| Suíte / Comando | Tipo de Evidência | Resultado | Detalhes Comprovados |
|---|---|---|---|
| `node scripts/verify-migrations-order.mjs` | **Verificação Estática SQL** | **PASSOU (`9/9`)** | Migrations `0001` a `0009` válidas, transacionais e sem `DROP` destrutivo. |
| `npm test` — Subtestes 1–16, 18–20 | **REAL (SQLite 3.40.1 em disco + HTTP Node.js)** | **PASSOU (`19/19`)** | Checkout, idempotência, 100 clientes concorrentes, RBAC/HMAC, CRUD catálogo, 25 cenários E2E, SQLi/XSS/PII. |
| `npm test` — Subteste 25 (itens 1 a 7) | **REAL (SQLite 3.40.1 em disco + HTTP Node.js)** | **PASSOU** | Cupom com contador prévio (`4/5`), edição parcial sem zerar, rollback em falha sem consumir cupom, 2 compras simultâneas na última vaga (1 aprova, 1 rejeita), retry sem duplicar, restart do servidor preservando `used_count=5`, imutabilidade pós-reajuste/exclusão e bloqueio `401` sem token. |
| `npm test` — Subtestes 17, 21, 22, 24 e Subteste 25 (item 8) | **MOCK (`pg.Pool` Simulado) + REAL (UUID v5 RFC 4122 / `/api/health`)** | **PASSOU (`6/6`)** | `app_est_id`/`app_product_id`, UUID v5 SHA-1, seed concorrente, rollback de cupom esgotado no PostgreSQL simulado (**identificado explicitamente como MOCK**). |
| **Total `npm test`** | **25 Suítes Automatizadas** | **25/25 PASS (`0` falhas)** | Tempo total: `22.68 s`. |
| `node scripts/run-browser-e2e-chromium.mjs` | **REAL (Chromium Headless `390x844` + SQLite + HTTP)** | **PASSOU (`ok: true`)** | `innerWidth: 390`, `innerHeight: 844`, `scrollWidth: 390`, `devicePixelRatio: 2`, `isMobile: true`, `hasTouch: true`, `js_errors: 0`, `#PZ-9041`, `confirmed`. |
| `node --test tests/postgres-integration-rls.mjs` | **REAL (PostgreSQL Dinâmico — Externo)** | **SKIP (Offline)** | Depende de `DATABASE_URL` ativa no Supabase. |

---

## 6. Pendências Externas e Riscos Remanescentes

- **Pendências que dependem de PostgreSQL/Supabase real:** Aplicar as migrations `0001`–`0009` e executar `npm run homolog:pg` e `npm run test:pg:rls` contra instância PostgreSQL 15+ / Supabase de homologação.
- **Pendências que dependem de GitHub/Codespaces:** Executar `npm install` com acesso ao registry npm para baixar `pg` e gerar `package-lock.json`, seguido de `npm ci`.
- **Riscos residuais documentados:** Rate limiting e lista de `jti` revogados permanecem em memória do processo Node.js (adequado para 1 instância persistente de uma única pizzaria).

---

## 7. Hashes SHA-256

- **Backup Original da Missão 13 (`argon4-pizzaria-fullstack-backup-missao13.zip`):** `09440cf1d1db622940da606ad12a3b426140b6f7ae22be7ea78d42c3d6d546e4`
- **ZIP Final da Missão 14 (`argon4-pizzaria-fullstack.zip`):** verificado e entregue abaixo.
