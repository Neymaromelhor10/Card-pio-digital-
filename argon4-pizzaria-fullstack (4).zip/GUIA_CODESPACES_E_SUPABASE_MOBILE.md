# GUIA PRÁTICO (MOBILE ANDROID): GITHUB CODESPACES E HOMOLOGAÇÃO SUPABASE — ARGON 4

Este guia foi preparado para execução direta pelo **celular Android** (navegador mobile no GitHub Codespaces ou Termux), sem expor senhas no repositório Git.

---

## 1. Abrir o Projeto no GitHub Codespaces pelo Celular

1. Extraia o arquivo `argon4-pizzaria-fullstack.zip` e suba a pasta `argon4-pizzaria-fullstack` para o seu repositório privado no GitHub.
2. No navegador do Android, abra o repositório no GitHub, toque no botão verde **`<> Code`**, selecione a aba **`Codespaces`** e toque em **`Create codespace on main`**.
3. O Codespaces lerá automaticamente `.devcontainer/devcontainer.json`, configurará **Node.js 20**, instalará a dependência `pg` (`npm install`) e encaminhará a porta **`3000`**.

---

## 2. Instalar Dependências e Gerar o `package-lock.json` Legítimo

No terminal integrado do Codespaces, execute:

```bash
npm install
npm ci
npm run check:env
```

- `npm install` baixa o pacote oficial `pg` do registry npm e cria o `package-lock.json` legítimo.
- `npm ci` valida que a instalação limpa e reproduzível funciona sem erros.
- `npm run check:env` exibe um JSON de diagnóstico (com `"pg_driver_installed": true`) sem mostrar nenhuma senha na tela.

---

## 3. Criar o Projeto de Homologação no Supabase e Obter a `DATABASE_URL`

1. Acesse o painel do Supabase pelo navegador do celular e crie um projeto separado chamado **`forno-nobre-homolog`** (nunca use um banco de produção com dados reais para testes).
2. Defina e guarde a senha do banco (`Database Password`).
3. No projeto criado, toque no botão **`Connect`** (no topo) -> selecione **`ORMs` / `Connection String`** -> **`URI`**.
4. Escolha **Session Pooler (porta `5432`)** ou **Transaction Pooler (porta `6543`)** e copie a URI:
   - Formato: `postgresql://postgres.[SEU_REF]:[SUA_SENHA]@aws-0-sa-east-1.pooler.supabase.com:5432/postgres`

---

## 4. Configurar Segredos com Segurança (Sem Versionar no Git)

### Opção A — GitHub Codespaces Secrets (Recomendado)
Em **GitHub Settings -> Codespaces -> Secrets**, adicione:
- `DATABASE_URL`: sua URI PostgreSQL do Supabase de homologação
- `ADMIN_API_TOKEN`: gere no terminal com `openssl rand -hex 32`
- `SESSION_SECRET`: gere no terminal com `openssl rand -hex 32`

### Opção B — Arquivo `.env` Local no Codespaces (Ignorado pelo `.gitignore`)
No terminal do Codespaces:

```bash
cp .env.example .env
```

Edite o `.env` preenchendo `DATABASE_DRIVER=postgres`, `DATABASE_URL`, `ADMIN_API_TOKEN` e `SESSION_SECRET`. O servidor (`npm start`) e os scripts (`npm run homolog:pg` e `npm run test:pg:rls`) carregam automaticamente o `.env` local via `server/src/envLoader.mjs`.

---

## 5. Executar Migrations, Homologação Real (15 Etapas) e Testes RLS

No terminal do Codespaces:

```bash
# 1. Verificar ordem e integridade das 9 migrations (0001 a 0009)
npm run verify:migrations

# 2. Aplicar migrations 0001-0009 no Supabase + rodar as 15 etapas (seed, catálogo, restart, rollback, 100 clientes concorrentes)
npm run homolog:pg

# 3. Executar testes dinâmicos de RLS (anon, authenticated, service_role e auditoria de conexão)
npm run test:pg:rls

# 4. Rodar suíte completa de regressão (23 suítes)
npm test
```

---

## 6. Subir o Servidor e Abrir o Cardápio e o Painel Admin no Celular

```bash
npm start
```

1. No painel inferior do Codespaces, toque na aba **`PORTS`** (Portas).
2. Localize a porta **`3000`** (`Argon 4 Cardápio Digital & API`) e toque no ícone de globo (**Open in Browser**) para abrir a URL `https://<seu-codespace>-3000.app.github.dev`.
3. O cardápio público carregará via `GET /api/catalog` e o painel administrativo poderá ser testado na mesma interface.

---

## 7. Como Interpretar e Resolver Erros Comuns

| Mensagem de Erro | Causa | Solução Imediata |
|---|---|---|
| `POSTGRES_CONFIG_MISSING` | `DATABASE_DRIVER=postgres` está ativo, mas `DATABASE_URL` está vazia ou sem prefixo `postgresql://`. | Preencha `DATABASE_URL` no `.env` ou nos Secrets do Codespaces. |
| `POSTGRES_DRIVER_NOT_INSTALLED` | O pacote `pg` ainda não foi instalado em `node_modules/`. | Execute `npm install` no terminal do Codespaces. |
| `DATABASE_CONNECTION_FAILED: password authentication failed` | Senha incorreta ou caracteres especiais (`@`, `#`, `?`) na senha sem URL-encode. | Confira a senha do banco no Supabase; se tiver caracteres especiais, substitua por `%40`, `%23`, etc. |
| `AUTH_CONFIG_MISSING_OR_INSECURE` | `NODE_ENV=production` foi ativado sem `ADMIN_API_TOKEN` ou `SESSION_SECRET` seguros (>= 32 chars). | Gere tokens fortes com `openssl rand -hex 32` e defina no `.env`. |
| `Connection drop / 502 Bad Gateway` na URL do Codespaces | O comando `npm start` foi encerrado no terminal. | Mantenha `npm start` rodando no terminal do Codespaces enquanto navega pela URL da aba `Ports`. |
